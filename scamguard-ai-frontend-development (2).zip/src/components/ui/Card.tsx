import { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glassmorphism?: boolean;
}

export default function Card({
  children,
  className = '',
  hover = true,
  glassmorphism = true,
}: CardProps) {
  const baseClasses = `rounded-2xl border transition-all duration-300 ${
    glassmorphism
      ? 'border-slate-700/50 bg-slate-800/40 backdrop-blur-xl'
      : 'border-slate-700 bg-slate-800'
  }`;

  const hoverClasses = hover ? 'hover:border-slate-600/50 hover:bg-slate-800/60 hover:shadow-xl hover:shadow-slate-900/50' : '';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`${baseClasses} ${hoverClasses} ${className}`}
    >
      {children}
    </motion.div>
  );
}
