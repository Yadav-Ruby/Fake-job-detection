import { ReactNode } from 'react';

type BadgeVariant = 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'info';
type BadgeSize = 'sm' | 'md' | 'lg';

interface BadgeProps {
  children: ReactNode;
  variant?: BadgeVariant;
  size?: BadgeSize;
  icon?: ReactNode;
  dotted?: boolean;
  dismissible?: boolean;
  onDismiss?: () => void;
  className?: string;
}

const variantStyles: Record<BadgeVariant, string> = {
  default: 'bg-slate-700/50 text-slate-200 border border-slate-600/50',
  primary: 'bg-red-500/20 text-red-300 border border-red-500/30',
  secondary: 'bg-blue-500/20 text-blue-300 border border-blue-500/30',
  success: 'bg-green-500/20 text-green-300 border border-green-500/30',
  warning: 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30',
  danger: 'bg-red-500/20 text-red-300 border border-red-500/30',
  info: 'bg-blue-500/20 text-blue-300 border border-blue-500/30',
};

const sizeStyles: Record<BadgeSize, string> = {
  sm: 'px-2 py-1 text-xs font-medium',
  md: 'px-3 py-1.5 text-sm font-medium',
  lg: 'px-4 py-2 text-base font-semibold',
};

const dottedIndicators: Record<BadgeVariant, string> = {
  default: 'bg-slate-400',
  primary: 'bg-red-400',
  secondary: 'bg-blue-400',
  success: 'bg-green-400',
  warning: 'bg-yellow-400',
  danger: 'bg-red-400',
  info: 'bg-blue-400',
};

export default function Badge({
  children,
  variant = 'default',
  size = 'md',
  icon,
  dotted = false,
  dismissible = false,
  onDismiss,
  className = '',
}: BadgeProps) {
  const baseClasses = 'inline-flex items-center gap-2 rounded-full font-inter font-semibold transition-all duration-200';

  return (
    <span className={`${baseClasses} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}>
      {dotted && (
        <span className={`inline-block w-2 h-2 rounded-full ${dottedIndicators[variant]}`} />
      )}
      {icon && <span className="flex items-center">{icon}</span>}
      <span>{children}</span>
      {dismissible && (
        <button
          onClick={onDismiss}
          className="ml-1 hover:opacity-70 transition-opacity flex items-center"
          aria-label="Dismiss"
        >
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      )}
    </span>
  );
}
