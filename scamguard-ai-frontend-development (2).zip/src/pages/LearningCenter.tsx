import { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Trophy, BarChart3, ChevronRight, Lock, Zap } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
}

export default function LearningCenter() {
  const [activeTab, setActiveTab] = useState<'categories' | 'articles' | 'quiz' | 'achievements'>('categories');

  const scamCategories = [
    {
      title: 'Fake Job Listings',
      count: 12,
      color: 'from-red-500/20 to-red-500/10',
      textColor: 'text-red-400',
      lessons: ['Spotting Red Flags', 'Common Tactics', 'Verification Tips'],
    },
    {
      title: 'Recruiter Scams',
      count: 8,
      color: 'from-orange-500/20 to-orange-500/10',
      textColor: 'text-orange-400',
      lessons: ['Fake Credentials', 'Email Verification', 'Professional Scams'],
    },
    {
      title: 'Registration Fees',
      count: 10,
      color: 'from-yellow-500/20 to-yellow-500/10',
      textColor: 'text-yellow-400',
      lessons: ['Fee Scams', 'Legitimate Costs', 'Payment Safety'],
    },
    {
      title: 'Phishing & Scams',
      count: 15,
      color: 'from-blue-500/20 to-blue-500/10',
      textColor: 'text-blue-400',
      lessons: ['Email Phishing', 'Link Detection', 'Data Protection'],
    },
  ];

  const articles = [
    {
      title: '10 Red Flags in Job Listings',
      category: 'Fake Jobs',
      readTime: 8,
      image: '📋',
    },
    {
      title: 'How to Verify Company Legitimacy',
      category: 'Verification',
      readTime: 12,
      image: '🔍',
    },
    {
      title: 'Understanding Phishing Tactics',
      category: 'Security',
      readTime: 10,
      image: '🎣',
    },
    {
      title: 'Protecting Your Personal Information',
      category: 'Safety',
      readTime: 9,
      image: '🛡️',
    },
    {
      title: 'WhatsApp Job Scams Explained',
      category: 'Messaging Apps',
      readTime: 7,
      image: '💬',
    },
    {
      title: 'Interview Process Red Flags',
      category: 'Hiring',
      readTime: 11,
      image: '🎤',
    },
  ];

  const achievements: Achievement[] = [
    {
      id: '1',
      name: 'Safety Scout',
      description: 'Complete 5 scam checks',
      icon: '🔍',
      unlocked: true,
      progress: 100,
    },
    {
      id: '2',
      name: 'Knowledge Seeker',
      description: 'Read 10 articles',
      icon: '📚',
      unlocked: true,
      progress: 100,
    },
    {
      id: '3',
      name: 'Quiz Master',
      description: 'Pass 3 safety quizzes',
      icon: '🧠',
      unlocked: false,
      progress: 66,
    },
    {
      id: '4',
      name: 'Protector',
      description: 'Verify 20 recruiters',
      icon: '🛡️',
      unlocked: false,
      progress: 40,
    },
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Learning Center</h1>
          <p className="text-slate-400 text-lg">Master scam identification and career safety</p>
        </motion.div>

        {/* Tabs */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap gap-2 mb-12 bg-slate-800/30 p-2 rounded-lg w-fit mx-auto">
          {[
            { id: 'categories', label: 'Categories', icon: BookOpen },
            { id: 'articles', label: 'Articles', icon: BookOpen },
            { id: 'quiz', label: 'Quiz', icon: Zap },
            { id: 'achievements', label: 'Achievements', icon: Trophy },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 font-medium ${
                activeTab === tab.id
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                  : 'text-slate-400 hover:text-slate-300'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </motion.div>

        {/* Content */}
        {activeTab === 'categories' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {scamCategories.map((category, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className={`p-6 bg-gradient-to-br ${category.color}`}>
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-semibold text-white">{category.title}</h3>
                    <span className={`px-3 py-1 rounded-full bg-slate-800/50 text-sm font-medium ${category.textColor}`}>
                      {category.count} lessons
                    </span>
                  </div>

                  <div className="space-y-2 mb-6">
                    {category.lessons.map((lesson, j) => (
                      <div key={j} className="flex items-center gap-2 text-slate-300 text-sm">
                        <ChevronRight className="h-4 w-4 text-slate-500" />
                        {lesson}
                      </div>
                    ))}
                  </div>

                  <Button variant="outline" size="md" className="w-full">
                    Explore
                  </Button>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {activeTab === 'articles' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {articles.map((article, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="p-6 h-full flex flex-col cursor-pointer hover:scale-105 transition-transform">
                  <div className="text-4xl mb-4">{article.image}</div>
                  <h3 className="text-lg font-semibold text-white mb-2">{article.title}</h3>
                  <p className="text-slate-400 text-sm mb-4 flex-1">{article.category}</p>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{article.readTime} min read</span>
                    <ChevronRight className="h-4 w-4" />
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {activeTab === 'quiz' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-w-2xl mx-auto"
          >
            <Card className="p-8 text-center">
              <div className="text-6xl mb-4">🧠</div>
              <h2 className="text-2xl font-bold text-white mb-4">Test Your Knowledge</h2>
              <p className="text-slate-400 mb-8">
                Take interactive quizzes to test your understanding of common scams and stay sharp on safety practices.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {[
                  { title: 'Beginner', questions: 10 },
                  { title: 'Intermediate', questions: 15 },
                  { title: 'Advanced', questions: 20 },
                  { title: 'Expert', questions: 25 },
                ].map((level, i) => (
                  <Button key={i} variant="outline" size="md" className="w-full">
                    <span>{level.title} ({level.questions}q)</span>
                  </Button>
                ))}
              </div>

              <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <p className="text-sm text-blue-300">
                  📊 Average Score: 8.7/10 | Quizzes Completed: 12 | Streak: 5 days
                </p>
              </div>
            </Card>
          </motion.div>
        )}

        {activeTab === 'achievements' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {achievements.map((achievement, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className={`p-6 text-center h-full flex flex-col ${!achievement.unlocked ? 'opacity-50' : ''}`}>
                  <div className="text-5xl mb-4">{achievement.icon}</div>
                  {!achievement.unlocked && (
                    <Lock className="h-6 w-6 mx-auto mb-2 text-slate-500" />
                  )}
                  <h3 className="text-lg font-semibold text-white mb-2">{achievement.name}</h3>
                  <p className="text-slate-400 text-sm mb-4 flex-1">{achievement.description}</p>

                  <div className="relative h-2 bg-slate-700/50 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${achievement.progress}%` }}
                      transition={{ duration: 1 }}
                      className="h-full bg-gradient-to-r from-red-500 to-red-600"
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-2">{achievement.progress}% Complete</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Progress Tracker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-16 max-w-2xl mx-auto"
        >
          <Card className="p-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">Your Progress</h3>
                <p className="text-slate-400">Keep learning to unlock more features</p>
              </div>
              <BarChart3 className="h-10 w-10 text-red-400" />
            </div>

            <div className="space-y-6">
              {[
                { label: 'Scam Checks Completed', value: 47, max: 100 },
                { label: 'Articles Read', value: 12, max: 50 },
                { label: 'Quizzes Passed', value: 8, max: 20 },
              ].map((stat, i) => (
                <div key={i}>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-300">{stat.label}</span>
                    <span className="text-white font-semibold">{stat.value}/{stat.max}</span>
                  </div>
                  <div className="relative h-2 bg-slate-700/50 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(stat.value / stat.max) * 100}%` }}
                      transition={{ duration: 1 }}
                      className="h-full bg-gradient-to-r from-red-500 to-red-600"
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
