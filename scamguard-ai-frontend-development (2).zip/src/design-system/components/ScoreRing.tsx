import { motion } from 'framer-motion';

type RiskLevel = 'safe' | 'warning' | 'danger';
type RingSize = 'sm' | 'md' | 'lg' | 'xl';

interface ScoreRingProps {
  score: number; // 0-100
  level?: RiskLevel;
  size?: RingSize;
  label?: string;
  subLabel?: string;
  showPercentage?: boolean;
  animated?: boolean;
  showStroke?: boolean;
}

const sizeConfig: Record<RingSize, { diameter: number; radius: number; strokeWidth: number; padding: number }> = {
  sm: { diameter: 80, radius: 32, strokeWidth: 6, padding: 8 },
  md: { diameter: 120, radius: 48, strokeWidth: 8, padding: 12 },
  lg: { diameter: 160, radius: 64, strokeWidth: 10, padding: 16 },
  xl: { diameter: 200, radius: 80, strokeWidth: 12, padding: 20 },
};

const colorConfig: Record<RiskLevel, { gradient: string; textColor: string; label: string }> = {
  safe: {
    gradient: 'from-green-400 to-green-600',
    textColor: 'text-green-400',
    label: 'Safe',
  },
  warning: {
    gradient: 'from-yellow-400 to-yellow-600',
    textColor: 'text-yellow-400',
    label: 'Warning',
  },
  danger: {
    gradient: 'from-red-400 to-red-600',
    textColor: 'text-red-400',
    label: 'Danger',
  },
};

export default function ScoreRing({
  score,
  level = 'safe',
  size = 'md',
  label,
  subLabel,
  showPercentage = true,
  animated = true,
  showStroke = true,
}: ScoreRingProps) {
  const config = sizeConfig[size];
  const colors = colorConfig[level];
  const circumference = 2 * Math.PI * config.radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const centerX = config.diameter / 2;
  const centerY = config.diameter / 2;

  // Font sizes based on ring size
  const fontSizeMap: Record<RingSize, string> = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl',
    xl: 'text-5xl',
  };

  const subFontSizeMap: Record<RingSize, string> = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
    xl: 'text-lg',
  };

  return (
    <div className="flex flex-col items-center justify-center">
      <div className={`relative inline-flex items-center justify-center`} style={{ width: config.diameter + config.padding * 2, height: config.diameter + config.padding * 2 }}>
        {/* Background circle */}
        <svg
          width={config.diameter}
          height={config.diameter}
          className="absolute -rotate-90"
          viewBox={`0 0 ${config.diameter} ${config.diameter}`}
        >
          {/* Background ring */}
          {showStroke && (
            <circle
              cx={centerX}
              cy={centerY}
              r={config.radius}
              fill="none"
              stroke="#334155"
              strokeWidth={config.strokeWidth}
              opacity={0.5}
            />
          )}

          {/* Animated progress ring */}
          <motion.circle
            cx={centerX}
            cy={centerY}
            r={config.radius}
            fill="none"
            stroke={level === 'safe' ? '#22C55E' : level === 'warning' ? '#FBBF24' : '#EF4444'}
            strokeWidth={config.strokeWidth}
            strokeDasharray={circumference}
            initial={animated ? { strokeDashoffset: circumference } : { strokeDashoffset }}
            animate={animated ? { strokeDashoffset } : {}}
            transition={animated ? { duration: 1.5, ease: 'easeInOut' } : {}}
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 8px ${level === 'safe' ? 'rgba(34, 197, 94, 0.3)' : level === 'warning' ? 'rgba(251, 191, 36, 0.3)' : 'rgba(239, 68, 68, 0.3)'})` }}
          />
        </svg>

        {/* Center content */}
        <div className="text-center z-10">
          <motion.div
            initial={animated ? { scale: 0 } : {}}
            animate={animated ? { scale: 1 } : {}}
            transition={animated ? { duration: 0.5, delay: 0.3 } : {}}
            className="flex flex-col items-center gap-1"
          >
            <div className={`${fontSizeMap[size]} font-bold ${colors.textColor} font-inter`}>
              {showPercentage && <>{score}%</>}
              {!showPercentage && <>{score}</>}
            </div>
            {label && <div className={`${subFontSizeMap[size]} text-slate-400 font-medium font-inter`}>{label}</div>}
            {subLabel && <div className={`${subFontSizeMap[size]} text-slate-500 font-inter`}>{subLabel}</div>}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
