import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Shield,
  TrendingUp,
  Users,
  Award,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Zap,
  Lock,
  Eye,
  MessageCircle,
  Download,
  Code,
  Share2,
} from 'lucide-react';
import Button from '../design-system/components/Button';

// Animation Variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8 },
  },
};

const floatingVariants = {
  initial: { y: 0 },
  animate: {
    y: [-20, 20, -20],
    transition: {
      duration: 6,
      repeat: Infinity,
    },
  },
};

const scaleVariants = {
  hidden: { scale: 0.8, opacity: 0 },
  visible: {
    scale: 1,
    opacity: 1,
    transition: { duration: 0.8 },
  },
};

export default function PremiumLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 py-20 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 -z-10">
          {/* Animated gradient background */}
          <div className="absolute -top-40 -right-40 h-96 w-96 bg-red-500/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute -bottom-40 -left-40 h-96 w-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute top-1/2 left-1/2 h-96 w-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        {/* Grid background */}
        <div className="absolute inset-0 -z-10 opacity-5">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                'linear-gradient(0deg, transparent 24%, rgba(255, 0, 0, .05) 25%, rgba(255, 0, 0, .05) 26%, transparent 27%, transparent 74%, rgba(255, 0, 0, .05) 75%, rgba(255, 0, 0, .05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(255, 0, 0, .05) 25%, rgba(255, 0, 0, .05) 26%, transparent 27%, transparent 74%, rgba(255, 0, 0, .05) 75%, rgba(255, 0, 0, .05) 76%, transparent 77%, transparent)',
              backgroundSize: '50px 50px',
            }}
          />
        </div>

        <div className="mx-auto max-w-7xl z-10">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="text-center space-y-8"
          >
            {/* Badge */}
            <motion.div variants={itemVariants} className="inline-flex items-center space-x-2 rounded-full border border-red-500/30 bg-red-500/10 px-6 py-3">
              <Zap className="h-4 w-4 text-red-400" />
              <span className="text-sm font-semibold text-red-300">🚀 Now Protecting 100K+ Students</span>
            </motion.div>

            {/* Main Headline */}
            <motion.div variants={itemVariants} className="space-y-4">
              <h1 className="text-6xl md:text-7xl lg:text-8xl font-bold tracking-tighter">
                <span className="bg-gradient-to-r from-red-400 via-red-500 to-red-600 bg-clip-text text-transparent">
                  Your Career Safety
                </span>
                <br />
                <span className="text-white">Guard</span>
              </h1>
              <p className="text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
                AI-powered platform that identifies fake jobs, recruiter scams, and phishing attempts in seconds. Stay safe, stay smart.
              </p>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              variants={itemVariants}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4"
            >
              <Link to="/scam-checker">
                <Button variant="primary" size="lg">
                  <Shield className="h-5 w-5" />
                  Check for Scams Now
                </Button>
              </Link>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 rounded-lg border-2 border-slate-700 text-slate-300 font-semibold hover:border-slate-600 hover:bg-slate-800/50 transition-all duration-200 flex items-center gap-2"
              >
                <Download className="h-5 w-5" />
                Watch Demo
              </motion.button>
            </motion.div>

            {/* Floating Cards */}
            <motion.div
              variants={itemVariants}
              className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-12 max-w-4xl mx-auto"
            >
              {[
                { icon: Shield, label: 'Instant Analysis', desc: 'Get results in seconds' },
                { icon: Lock, label: '100% Safe', desc: 'No data collection' },
                { icon: Award, label: '99.2% Accurate', desc: 'AI-powered detection' },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  variants={scaleVariants}
                  whileHover={{ y: -5 }}
                  className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/50 backdrop-blur-xl hover:border-red-500/30 transition-all duration-300"
                >
                  <item.icon className="h-6 w-6 text-red-400 mb-2 mx-auto" />
                  <p className="font-semibold text-white text-sm">{item.label}</p>
                  <p className="text-xs text-slate-400 mt-1">{item.desc}</p>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Trust Metrics Section */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Trusted by <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">Students Worldwide</span>
            </h2>
            <p className="text-xl text-slate-400">Real numbers from real students who stayed safe</p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {[
              { icon: Users, stat: '100K+', label: 'Active Users', color: 'text-blue-400' },
              { icon: AlertCircle, stat: '50K+', label: 'Scams Detected', color: 'text-red-400' },
              { icon: Award, stat: '99.2%', label: 'Accuracy Rate', color: 'text-green-400' },
              { icon: TrendingUp, stat: '24/7', label: 'AI Protection', color: 'text-yellow-400' },
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                whileHover={{ scale: 1.05, y: -5 }}
                className="group relative p-8 rounded-2xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 border border-slate-700/50 backdrop-blur-xl hover:border-red-500/30 transition-all duration-300"
              >
                {/* Background gradient on hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/0 to-blue-500/0 group-hover:from-red-500/5 group-hover:to-blue-500/5 rounded-2xl transition-all duration-300" />

                <div className="relative z-10">
                  <item.icon className={`h-10 w-10 mb-4 ${item.color}`} />
                  <div className="text-4xl font-bold text-white mb-2">{item.stat}</div>
                  <div className="text-slate-400 font-medium">{item.label}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Scam Trends Section */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-red-500/5 to-transparent">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Threats We <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">Detect & Stop</span>
            </h2>
            <p className="text-xl text-slate-400">Common scams targeting students - we catch them all</p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {[
              {
                title: 'Fake Job Listings',
                desc: 'Deceptive job postings designed to steal personal data',
                icon: '💼',
                stats: '45% of scams',
                risk: 'Critical',
              },
              {
                title: 'Recruiter Scams',
                desc: 'Impersonating legitimate recruiters for financial gain',
                icon: '👤',
                stats: '28% of scams',
                risk: 'High',
              },
              {
                title: 'Registration Fees',
                desc: 'Hidden fees for non-existent job opportunities',
                icon: '💰',
                stats: '32% of scams',
                risk: 'High',
              },
              {
                title: 'Phishing Attempts',
                desc: 'Malicious links targeting student credentials',
                icon: '🎣',
                stats: '18% of scams',
                risk: 'High',
              },
              {
                title: 'WhatsApp Scams',
                desc: 'Unofficial hiring via messaging applications',
                icon: '💬',
                stats: '22% of scams',
                risk: 'Medium',
              },
              {
                title: 'Telegram Threats',
                desc: 'Anonymous offers with suspicious conditions',
                icon: '📱',
                stats: '15% of scams',
                risk: 'Medium',
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                whileHover={{ y: -8, scale: 1.02 }}
                className="group relative p-6 rounded-xl bg-slate-800/40 border border-slate-700/50 backdrop-blur-xl hover:border-red-500/30 transition-all duration-300 overflow-hidden"
              >
                {/* Hover glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/0 to-transparent group-hover:from-red-500/10 rounded-xl transition-all duration-300" />

                <div className="relative z-10">
                  <div className="text-4xl mb-4">{item.icon}</div>
                  <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-slate-400 text-sm mb-4">{item.desc}</p>
                  <div className="flex justify-between items-center pt-4 border-t border-slate-700/30">
                    <span className="text-xs text-slate-500">{item.stats}</span>
                    <span
                      className={`text-xs font-semibold px-2 py-1 rounded-full ${
                        item.risk === 'Critical'
                          ? 'bg-red-500/20 text-red-300'
                          : item.risk === 'High'
                            ? 'bg-orange-500/20 text-orange-300'
                            : 'bg-yellow-500/20 text-yellow-300'
                      }`}
                    >
                      {item.risk}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Powerful <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">Features</span>
            </h2>
            <p className="text-xl text-slate-400">Everything you need to stay safe</p>
          </motion.div>

          {/* Feature 1 */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            <div className="order-2 lg:order-1">
              <motion.div variants={floatingVariants} initial="initial" animate="animate" className="relative">
                <div className="aspect-video rounded-2xl bg-gradient-to-br from-red-500/20 to-blue-500/20 border border-slate-700/50 flex items-center justify-center overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-transparent" />
                  <Shield className="h-24 w-24 text-red-400/30 group-hover:text-red-400/50 transition-colors" />
                </div>
              </motion.div>
            </div>

            <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }} className="order-1 lg:order-2 space-y-6">
              <div>
                <h3 className="text-4xl font-bold text-white mb-3">Instant Scam Detection</h3>
                <p className="text-lg text-slate-400 mb-6">Paste a job link, description, or screenshot. Our AI analyzes it in real-time and tells you if it's safe.</p>
              </div>

              {[
                'Real-time analysis with AI',
                'Multiple input methods (URL, text, screenshot)',
                'Detailed fraud signal breakdown',
                'Instant risk scoring (0-100%)',
              ].map((feature, i) => (
                <motion.div
                  key={i}
                  variants={itemVariants}
                  className="flex items-start gap-4 group"
                >
                  <div className="mt-1 flex-shrink-0">
                    <CheckCircle2 className="h-6 w-6 text-green-400 group-hover:text-green-300 transition-colors" />
                  </div>
                  <span className="text-slate-300 group-hover:text-white transition-colors">{feature}</span>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Feature 2 */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }} className="space-y-6">
              <div>
                <h3 className="text-4xl font-bold text-white mb-3">Recruiter Verification</h3>
                <p className="text-lg text-slate-400 mb-6">Verify recruiter legitimacy before sharing your personal information. Check trust scores, domain age, and history.</p>
              </div>

              {[
                'Email-based recruiter lookup',
                'Trust scoring (0-100%)',
                'Domain age verification',
                'Fraud report database access',
              ].map((feature, i) => (
                <motion.div
                  key={i}
                  variants={itemVariants}
                  className="flex items-start gap-4 group"
                >
                  <div className="mt-1 flex-shrink-0">
                    <CheckCircle2 className="h-6 w-6 text-green-400 group-hover:text-green-300 transition-colors" />
                  </div>
                  <span className="text-slate-300 group-hover:text-white transition-colors">{feature}</span>
                </motion.div>
              ))}
            </motion.div>

            <div>
              <motion.div variants={floatingVariants} initial="initial" animate="animate" className="relative">
                <div className="aspect-video rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-slate-700/50 flex items-center justify-center overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent" />
                  <Users className="h-24 w-24 text-blue-400/30 group-hover:text-blue-400/50 transition-colors" />
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Feature 3 */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          >
            <div className="order-2 lg:order-1">
              <motion.div variants={floatingVariants} initial="initial" animate="animate" className="relative">
                <div className="aspect-video rounded-2xl bg-gradient-to-br from-green-500/20 to-blue-500/20 border border-slate-700/50 flex items-center justify-center overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-transparent" />
                  <Eye className="h-24 w-24 text-green-400/30 group-hover:text-green-400/50 transition-colors" />
                </div>
              </motion.div>
            </div>

            <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }} className="order-1 lg:order-2 space-y-6">
              <div>
                <h3 className="text-4xl font-bold text-white mb-3">Learning & Community</h3>
                <p className="text-lg text-slate-400 mb-6">Learn about scams, take safety quizzes, earn achievements, and help others by reporting suspicious activity.</p>
              </div>

              {[
                '45+ educational lessons',
                'Interactive safety quizzes',
                'Achievement system',
                'Community scam database',
              ].map((feature, i) => (
                <motion.div
                  key={i}
                  variants={itemVariants}
                  className="flex items-start gap-4 group"
                >
                  <div className="mt-1 flex-shrink-0">
                    <CheckCircle2 className="h-6 w-6 text-green-400 group-hover:text-green-300 transition-colors" />
                  </div>
                  <span className="text-slate-300 group-hover:text-white transition-colors">{feature}</span>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
              How It <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">Works</span>
            </h2>
            <p className="text-xl text-slate-400">Three simple steps to stay safe</p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              {
                step: 1,
                icon: Shield,
                title: 'Submit Info',
                desc: 'Paste a job link, description, or screenshot to analyze',
              },
              {
                step: 2,
                icon: Zap,
                title: 'AI Analysis',
                desc: 'Our machine learning model analyzes for fraud signals',
              },
              {
                step: 3,
                icon: Award,
                title: 'Get Results',
                desc: 'Instant risk score and detailed security recommendations',
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                className="relative text-center group"
              >
                {/* Step indicator */}
                <motion.div
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: i * 0.1 }}
                  className="mx-auto mb-6 h-16 w-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center font-bold text-white text-2xl shadow-lg shadow-blue-500/30 group-hover:shadow-blue-500/50 transition-all duration-300"
                >
                  {item.step}
                </motion.div>

                {/* Arrow */}
                {i < 2 && (
                  <div className="hidden md:block absolute top-8 -right-4 text-slate-700">
                    <ArrowRight className="h-6 w-6 group-hover:translate-x-2 transition-transform" />
                  </div>
                )}

                {/* Content */}
                <h3 className="text-2xl font-bold text-white mb-2">{item.title}</h3>
                <p className="text-slate-400">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Loved by <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">1000+ Students</span>
            </h2>
            <p className="text-xl text-slate-400">Real stories from students who stayed safe</p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            {[
              {
                name: 'Sarah M.',
                role: 'Engineering Student',
                text: 'ScamGuard saved me from a fake Google internship. I was almost about to fall for it!',
                rating: 5,
                avatar: '👩‍💻',
              },
              {
                name: 'Raj P.',
                role: 'Business Major',
                text: 'The recruiter verification tool is incredibly accurate. Found out my contact was blacklisted!',
                rating: 5,
                avatar: '👨‍💼',
              },
              {
                name: 'Emma L.',
                role: 'CS Student',
                text: 'Finally a tool that protects students like us. This should be mandatory for every college!',
                rating: 5,
                avatar: '👩‍🎓',
              },
            ].map((testimonial, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                whileHover={{ y: -5 }}
                className="p-6 rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 border border-slate-700/50 backdrop-blur-xl hover:border-red-500/30 transition-all duration-300"
              >
                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, j) => (
                    <span key={j} className="text-yellow-400 text-lg">
                      ★
                    </span>
                  ))}
                </div>

                {/* Quote */}
                <p className="text-slate-300 mb-6 italic text-lg leading-relaxed">"{testimonial.text}"</p>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4 border-t border-slate-700/30">
                  <div className="text-4xl">{testimonial.avatar}</div>
                  <div>
                    <p className="font-semibold text-white">{testimonial.name}</p>
                    <p className="text-slate-400 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-red-500/5 to-transparent">
        <div className="mx-auto max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Frequently <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">Asked Questions</span>
            </h2>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-4"
          >
            {[
              {
                q: 'Is ScamGuard AI really free?',
                a: 'Yes! ScamGuard is completely free for all students. We believe career safety is a fundamental right. Premium features coming soon.',
              },
              {
                q: 'How accurate is the detection?',
                a: 'Our AI model has 99.2% accuracy based on industry data and patterns. We continuously improve with every new report.',
              },
              {
                q: 'Is my data safe and private?',
                a: 'Absolutely. We never store your personal data. Everything is encrypted and processed locally. Your privacy is our priority.',
              },
              {
                q: 'Can I report a scam I encountered?',
                a: 'Yes! Report scams directly in the app. Your reports help improve our model and protect other students.',
              },
              {
                q: 'How often is the database updated?',
                a: 'Our fraud database updates in real-time as new scams are reported and detected. We monitor threats 24/7.',
              },
              {
                q: 'Does it work on mobile?',
                a: 'Yes, ScamGuard works perfectly on mobile browsers. We are also developing native apps for iOS and Android.',
              },
            ].map((faq, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                whileHover={{ x: 5 }}
                className="group p-6 rounded-xl bg-slate-800/40 border border-slate-700/50 backdrop-blur-xl hover:border-red-500/30 transition-all duration-300 cursor-pointer"
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <MessageCircle className="h-6 w-6 text-red-400 mt-1" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-red-400 transition-colors">
                      {faq.q}
                    </h3>
                    <p className="text-slate-400 leading-relaxed">{faq.a}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="relative py-24 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative rounded-3xl overflow-hidden"
          >
            {/* Background gradients */}
            <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-blue-500/20 blur-2xl" />
            <div className="absolute inset-0 bg-gradient-to-b from-red-500/10 via-transparent to-blue-500/10" />

            <div className="relative z-10 p-12 md:p-16 text-center border border-red-500/30 rounded-3xl backdrop-blur-xl">
              <motion.h2
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-4xl md:text-5xl font-bold text-white mb-4"
              >
                Ready to Stay <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">Safe?</span>
              </motion.h2>

              <motion.p
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto leading-relaxed"
              >
                Join thousands of students protecting their career today. It takes just 30 seconds to check a job offer.
              </motion.p>

              <motion.div
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="flex flex-col sm:flex-row gap-4 justify-center items-center"
              >
                <Link to="/scam-checker">
                  <Button variant="primary" size="lg">
                    <Shield className="h-5 w-5" />
                    Start Checking Now
                  </Button>
                </Link>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 rounded-lg border-2 border-slate-700 text-slate-300 font-semibold hover:border-slate-600 hover:bg-slate-800/50 transition-all duration-200"
                >
                  Learn More
                </motion.button>
              </motion.div>

              {/* Subtext */}
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="text-slate-500 text-sm mt-6"
              >
                ✓ No sign-up required · ✓ Completely free · ✓ Results in seconds
              </motion.p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-12 px-4 sm:px-6 lg:px-8 border-t border-slate-800/50">
        <div className="mx-auto max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8"
          >
            {[
              { title: 'Product', links: ['Scam Checker', 'Recruiter Verify', 'Learning Center'] },
              { title: 'Company', links: ['About', 'Blog', 'Careers'] },
              { title: 'Legal', links: ['Privacy', 'Terms', 'Contact'] },
              { title: 'Social', links: ['Twitter', 'LinkedIn', 'GitHub'] },
            ].map((col, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <h4 className="font-semibold text-white mb-4">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map((link, j) => (
                    <li key={j}>
                      <a href="#" className="text-slate-400 hover:text-white transition-colors text-sm">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="border-t border-slate-800/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4"
          >
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-400" />
              <span className="font-semibold text-white">ScamGuard AI</span>
            </div>
            <p className="text-slate-400 text-sm">© 2024 ScamGuard AI. Protecting students from career scams.</p>
            <div className="flex gap-4">
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Code className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Share2 className="h-5 w-5" />
              </a>
            </div>
          </motion.div>
        </div>
      </footer>
    </div>
  );
}
