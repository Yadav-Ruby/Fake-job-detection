import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Send,
  MessageCircle,
  Trash2,
  Plus,
  Copy,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Brain,
  Zap,
  AlertCircle,
  Shield,
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
  isTyping?: boolean;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
}

const suggestedQuestions = [
  {
    icon: AlertCircle,
    title: 'Red Flags',
    description: 'What are the biggest red flags in job scams?',
    question: 'What are the most common red flags I should look for in potentially fraudulent job offers?',
  },
  {
    icon: Shield,
    title: 'Protection Tips',
    description: 'How can I protect myself online?',
    question: 'What are the best practices for protecting myself from recruiter scams and phishing attempts?',
  },
  {
    icon: Brain,
    title: 'Verify Jobs',
    description: 'How do I verify a job is real?',
    question: 'What steps should I take to verify that a job posting is legitimate before applying?',
  },
  {
    icon: Zap,
    title: 'Quick Tips',
    description: 'Give me safety tips',
    question: 'Give me 5 quick safety tips for job hunting that every student should know.',
  },
];

const conversationStarters = [
  'I received a job offer via WhatsApp. Is this normal?',
  'The recruiter asked for my social security number. Should I provide it?',
  'How can I verify a company before applying?',
  'What should I do if I suspect a scam?',
  'Are unpaid internships safe?',
  'What are common phishing tactics in hiring?',
];

export default function ModernCareerAssistant() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);



  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const createNewConversation = () => {
    const id = Date.now().toString();
    const newConversation: Conversation = {
      id,
      title: 'New Conversation',
      messages: [],
      createdAt: new Date(),
    };
    setConversations([newConversation, ...conversations]);
    setCurrentConversationId(id);
    setMessages([]);
  };

  const handleSendMessage = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim()) return;

    // Create new conversation if needed
    if (!currentConversationId) {
      const id = Date.now().toString();
      const newConversation: Conversation = {
        id,
        title: messageText.slice(0, 30) + (messageText.length > 30 ? '...' : ''),
        messages: [],
        createdAt: new Date(),
      };
      setConversations([newConversation, ...conversations]);
      setCurrentConversationId(id);
    }

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: messageText,
      sender: 'user',
      timestamp: new Date(),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    // Simulate assistant response with typing animation
    await new Promise((resolve) => setTimeout(resolve, 800));

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: generateResponse(messageText),
      sender: 'assistant',
      timestamp: new Date(),
      isTyping: true,
    };

    setMessages([...newMessages, assistantMessage]);

    // Animate typing effect
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setMessages([...newMessages, { ...assistantMessage, isTyping: false }]);
    setIsLoading(false);
  };

  const generateResponse = (question: string): string => {
    const lowerQuestion = question.toLowerCase();

    if (
      lowerQuestion.includes('red flag') ||
      lowerQuestion.includes('warning') ||
      lowerQuestion.includes('suspicious')
    ) {
      return `Great question! Here are the biggest red flags to watch for in job scams:

🚩 **Common Red Flags:**
1. **Unrealistic Salary** - Offers that seem too good to be true often are
2. **Upfront Payments** - Legitimate companies never ask for registration fees
3. **Poor Communication** - Grammar errors, vague job descriptions
4. **Unofficial Channels** - Job offers via WhatsApp, Telegram instead of official email
5. **No Interview Process** - Immediate hiring without technical assessment
6. **Generic Job Description** - Copy-paste job postings with no specifics
7. **Domain Spoofing** - Emails from "company.tk" instead of "company.com"
8. **Pressure to Decide** - "Apply immediately" or "Limited spots available"

If you see any of these, it's safer to move on and apply through the company's official website instead. Always verify independently!`;
    }

    if (
      lowerQuestion.includes('protect') ||
      lowerQuestion.includes('safety') ||
      lowerQuestion.includes('safe')
    ) {
      return `Excellent question! Here are proven strategies to protect yourself from job scams:

🛡️ **Protection Best Practices:**

**Before Applying:**
- Visit the company website directly (don't click email links)
- Verify the job posting on official career pages
- Check company social media and recent news
- Research the company using Glassdoor, LinkedIn

**During Communication:**
- Never share SSN, bank details, or ID numbers upfront
- Use secure communication channels
- Verify sender email addresses carefully
- Don't download suspicious files or attachments
- Beware of generic greetings ("Dear Candidate")

**Documentation:**
- Keep all communications saved
- Screenshot suspicious messages
- Document dates and times
- Save email headers

**Verification Tools:**
- Check domain ownership with WHOIS lookup
- Verify email addresses are legitimate
- Use reverse image search for profile pictures
- Cross-reference on company LinkedIn

Remember: Real companies will respect your caution and answer verification questions!`;
    }

    if (lowerQuestion.includes('verify') || lowerQuestion.includes('legitimate')) {
      return `Perfect timing! Verification is crucial. Here's your step-by-step verification guide:

✓ **How to Verify a Job is Real:**

**Step 1: Check the Source**
- Go directly to company.com (type in address bar, don't click links)
- Look for the careers or jobs page
- Search for the exact position title
- Compare job descriptions

**Step 2: Verify Contact**
- Find official contact on company website
- Call the main number and ask about the position
- Email recruiting@company.com directly
- Ask for recruiter's full name and LinkedIn profile

**Step 3: Research the Company**
- Check recent funding/news (legitimate companies make news)
- Look for company reviews on Glassdoor, Indeed
- Check LinkedIn company page
- Verify office locations and phone number

**Step 4: Interview Process**
- Real companies always have multiple interviews
- Technical roles have technical assessments
- You'll speak to actual team members
- Process usually takes 2-4 weeks

**Red Flag Alert:**
- No interview or assessment = 🚨 SCAM
- Immediate hire = 🚨 SCAM
- No company website = 🚨 SCAM
- Only email communication = ⚠️ SUSPICIOUS

Trust your gut! If something feels off, ask questions or move on.`;
    }

    if (lowerQuestion.includes('whatsapp') || lowerQuestion.includes('telegram')) {
      return `Great question! This is increasingly common. Here's what you need to know:

💬 **About Messaging App Job Offers:**

**Is It Normal?**
- ❌ NOT normal for official job offers
- ❌ Legitimate companies use email
- ⚠️ Could indicate scam or unprofessional employer

**Why Scammers Use WhatsApp/Telegram:**
- Harder to trace
- Creates urgency
- Less formal accountability
- Easier to disappear

**What to Do:**
1. **Don't Share Personal Info** - SSN, bank, ID numbers
2. **Verify the Company** - Contact them directly via official website
3. **Ask for Official Email** - "Can you email me from the company domain?"
4. **Request Company Details** - HR contact, office address, phone
5. **Meet in Person** - Real interviews happen in offices or video calls

**If They Refuse to:**
- Use official company email
- Provide verifiable contact info
- Conduct formal interviews
- Meet on video calls

→ **It's likely a scam. Block and report.**

**Always Remember:**
Real companies respect your caution and will be happy to verify themselves through official channels!`;
    }

    return `Thank you for your question! I'm here to help you stay safe in your career journey.

Here's what I can help you with:

📚 **Career Safety Topics:**
- Identifying job scams and red flags
- Verifying job legitimacy
- Protecting your personal information
- Understanding recruiter tactics
- Safe job search practices
- What to do if you suspect a scam

💡 **Ask me about:**
- Specific job offers you're unsure about
- Recruiter interactions that seem off
- How to verify companies
- Your rights as a job seeker
- Interview process best practices

🛡️ **I'm designed to help:**
- Explain common scam patterns
- Walk through verification steps
- Answer safety questions
- Provide peace of mind
- Share protective strategies

Feel free to ask about anything related to job search safety. The more specific your question, the better I can help!`;
  };

  const clearHistory = () => {
    setConversations([]);
    setCurrentConversationId(null);
    setMessages([]);
  };

  const deleteConversation = (id: string) => {
    setConversations(conversations.filter((c) => c.id !== id));
    if (currentConversationId === id) {
      setCurrentConversationId(null);
      setMessages([]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex overflow-hidden">
      {/* Sidebar */}
      <motion.div
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        className={`${
          showSidebar ? 'w-64' : 'w-0'
        } transition-all duration-300 border-r border-slate-800 bg-slate-950/80 backdrop-blur-xl flex flex-col overflow-hidden`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-slate-800">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={createNewConversation}
            className="w-full px-4 py-2 rounded-lg bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold hover:from-red-600 hover:to-red-700 transition-all flex items-center justify-center gap-2"
          >
            <Plus className="h-4 w-4" />
            New Chat
          </motion.button>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="p-4 text-center text-slate-500 text-sm">
              <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No conversations yet</p>
            </div>
          ) : (
            <div className="space-y-2 p-4">
              {conversations.map((conv) => (
                <motion.button
                  key={conv.id}
                  whileHover={{ x: 2 }}
                  onClick={() => {
                    setCurrentConversationId(conv.id);
                    setMessages(conv.messages);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-all group ${
                    currentConversationId === conv.id
                      ? 'bg-red-500/20 border border-red-500/30 text-red-300'
                      : 'text-slate-400 hover:bg-slate-800/50 border border-transparent'
                  }`}
                >
                  <p className="text-sm truncate font-medium">{conv.title}</p>
                  <p className="text-xs opacity-70">
                    {new Date(conv.createdAt).toLocaleDateString()}
                  </p>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteConversation(conv.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </motion.button>
              ))}
            </div>
          )}
        </div>

        {/* Clear History */}
        {conversations.length > 0 && (
          <div className="p-4 border-t border-slate-800">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={clearHistory}
              className="w-full px-3 py-2 rounded-lg text-sm text-slate-400 hover:text-slate-300 border border-slate-700 hover:bg-slate-800/50 transition-all flex items-center justify-center gap-2"
            >
              <Trash2 className="h-4 w-4" />
              Clear All
            </motion.button>
          </div>
        )}
      </motion.div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-4xl px-4 py-8">
            {messages.length === 0 ? (
              // Empty State
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="h-full flex flex-col items-center justify-center space-y-8"
              >
                {/* Logo */}
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  className="relative"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-red-600 rounded-3xl blur-2xl opacity-30"></div>
                  <div className="relative rounded-3xl bg-gradient-to-br from-red-500 to-red-600 p-6 shadow-2xl">
                    <Brain className="h-12 w-12 text-white" />
                  </div>
                </motion.div>

                {/* Title */}
                <div className="text-center space-y-2">
                  <h1 className="text-4xl font-bold text-white">Career Safety Assistant</h1>
                  <p className="text-slate-400 text-lg">
                    Your AI-powered guide for safe job searching
                  </p>
                </div>

                {/* Suggested Prompts */}
                <motion.div
                  variants={{
                    hidden: { opacity: 0 },
                    visible: {
                      opacity: 1,
                      transition: {
                        staggerChildren: 0.1,
                        delayChildren: 0.2,
                      },
                    },
                  }}
                  initial="hidden"
                  animate="visible"
                  className="w-full grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl"
                >
                  {suggestedQuestions.map((item, idx) => (
                    <motion.button
                      key={idx}
                      variants={{
                        hidden: { opacity: 0, y: 20 },
                        visible: { opacity: 1, y: 0 },
                      }}
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleSendMessage(item.question)}
                      className="p-4 rounded-xl border border-slate-700/50 bg-slate-800/40 hover:bg-slate-800/60 hover:border-red-500/30 transition-all text-left group"
                    >
                      <item.icon className="h-5 w-5 text-red-400 mb-2 group-hover:scale-110 transition-transform" />
                      <p className="font-semibold text-white text-sm">{item.title}</p>
                      <p className="text-slate-400 text-xs mt-1">{item.description}</p>
                    </motion.button>
                  ))}
                </motion.div>

                {/* Tips */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="text-center space-y-2 text-sm text-slate-500"
                >
                  <p>💡 Ask me about red flags, verification, or safety tips</p>
                  <p>🔒 All conversations are private and secure</p>
                </motion.div>
              </motion.div>
            ) : (
              // Chat Messages
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {messages.map((message, idx) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-2xl ${
                        message.sender === 'user'
                          ? 'bg-gradient-to-r from-red-500 to-red-600 text-white'
                          : 'bg-slate-800/50 border border-slate-700/50 text-slate-100'
                      } rounded-2xl px-6 py-4`}
                    >
                      {message.isTyping ? (
                        <div className="flex items-center gap-2">
                          <motion.span
                            animate={{ opacity: [0.4, 1, 0.4] }}
                            transition={{ duration: 1.5, repeat: Infinity }}
                            className="inline-block w-2 h-2 rounded-full bg-current"
                          />
                          <motion.span
                            animate={{ opacity: [0.4, 1, 0.4] }}
                            transition={{ duration: 1.5, repeat: Infinity, delay: 0.2 }}
                            className="inline-block w-2 h-2 rounded-full bg-current"
                          />
                          <motion.span
                            animate={{ opacity: [0.4, 1, 0.4] }}
                            transition={{ duration: 1.5, repeat: Infinity, delay: 0.4 }}
                            className="inline-block w-2 h-2 rounded-full bg-current"
                          />
                        </div>
                      ) : (
                        <div className="prose prose-invert max-w-none text-sm leading-relaxed">
                          {message.content.split('\n').map((line, i) => (
                            <p key={i} className="mb-2 last:mb-0 whitespace-pre-wrap">
                              {line}
                            </p>
                          ))}
                        </div>
                      )}

                      {message.sender === 'assistant' && !message.isTyping && (
                        <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-700/30">
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="p-2 rounded-lg hover:bg-slate-700/50 transition-colors"
                          >
                            <Copy className="h-4 w-4 opacity-70 hover:opacity-100" />
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="p-2 rounded-lg hover:bg-slate-700/50 transition-colors"
                          >
                            <ThumbsUp className="h-4 w-4 opacity-70 hover:opacity-100" />
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="p-2 rounded-lg hover:bg-slate-700/50 transition-colors"
                          >
                            <ThumbsDown className="h-4 w-4 opacity-70 hover:opacity-100" />
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="p-2 rounded-lg hover:bg-slate-700/50 transition-colors"
                          >
                            <Share2 className="h-4 w-4 opacity-70 hover:opacity-100" />
                          </motion.button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
                <div ref={messagesEndRef} />
              </motion.div>
            )}
          </div>
        </div>

        {/* Input Area */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="border-t border-slate-800 bg-gradient-to-t from-slate-950 to-transparent backdrop-blur-xl p-4 sm:p-6"
        >
          <div className="mx-auto max-w-4xl">
            {/* Quick suggestions if no messages */}
            {messages.length === 0 && (
              <div className="mb-4 flex flex-wrap gap-2">
                {conversationStarters.slice(0, 3).map((starter, idx) => (
                  <motion.button
                    key={idx}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.3 + idx * 0.05 }}
                    whileHover={{ scale: 1.05 }}
                    onClick={() => handleSendMessage(starter)}
                    className="text-xs px-3 py-1.5 rounded-full bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:text-white hover:border-red-500/30 transition-all"
                  >
                    {starter}
                  </motion.button>
                ))}
              </div>
            )}

            {/* Input */}
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Ask about job safety, red flags, verification..."
                className="flex-1 bg-slate-800/50 border border-slate-700/50 rounded-xl px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20 transition-all"
                disabled={isLoading}
              />

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSendMessage()}
                disabled={!input.trim() || isLoading}
                className="px-4 py-3 rounded-xl bg-gradient-to-r from-red-500 to-red-600 text-white hover:from-red-600 hover:to-red-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isLoading ? (
                  <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </motion.button>

              {/* Sidebar Toggle */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowSidebar(!showSidebar)}
                className="px-3 py-3 rounded-xl border border-slate-700/50 bg-slate-800/50 text-slate-300 hover:text-white hover:border-slate-600/50 transition-all"
              >
                {showSidebar ? '✕' : '≡'}
              </motion.button>
            </div>

            {/* Help Text */}
            <p className="text-xs text-slate-500 mt-3">
              Press Enter to send. Shift + Enter for new line. All conversations are private.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
