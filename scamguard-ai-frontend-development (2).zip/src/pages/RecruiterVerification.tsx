import { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, AlertCircle, XCircle, Globe, Calendar, Lock, AlertTriangle, TrendingUp } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

type VerificationStatus = 'verified' | 'suspicious' | 'blacklisted';

interface RecruiterProfile {
  name: string;
  company: string;
  email: string;
  domain: string;
  status: VerificationStatus;
  trustScore: number;
  domainAge: number;
  sslStatus: boolean;
  reports: number;
  verified: boolean;
}

export default function RecruiterVerification() {
  const [email, setEmail] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [recruiter, setRecruiter] = useState<RecruiterProfile | null>(null);

  const handleSearch = () => {
    if (email.trim()) {
      setHasSearched(true);
      // Simulate API call
      const statuses: VerificationStatus[] = ['verified', 'suspicious', 'blacklisted'];
      const status = statuses[Math.floor(Math.random() * 3)];
      
      setRecruiter({
        name: 'John Smith',
        company: 'Tech Corp Inc.',
        email: email,
        domain: email.split('@')[1] || 'domain.com',
        status,
        trustScore: status === 'verified' ? 92 : status === 'suspicious' ? 45 : 8,
        domainAge: status === 'verified' ? 12 : status === 'suspicious' ? 0.5 : 0.1,
        sslStatus: status !== 'blacklisted',
        reports: status === 'verified' ? 0 : status === 'suspicious' ? 3 : 25,
        verified: status === 'verified',
      });
    }
  };

  const statusConfig = {
    verified: {
      icon: CheckCircle2,
      label: 'Verified',
      color: 'text-green-400',
      bg: 'bg-green-500/10',
      border: 'border-green-500/30',
      badge: 'bg-green-500/20 text-green-300',
    },
    suspicious: {
      icon: AlertCircle,
      label: 'Suspicious',
      color: 'text-yellow-400',
      bg: 'bg-yellow-500/10',
      border: 'border-yellow-500/30',
      badge: 'bg-yellow-500/20 text-yellow-300',
    },
    blacklisted: {
      icon: XCircle,
      label: 'Blacklisted',
      color: 'text-red-400',
      bg: 'bg-red-500/10',
      border: 'border-red-500/30',
      badge: 'bg-red-500/20 text-red-300',
    },
  };

  return (
    <div className="min-h-screen py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Recruiter Verification</h1>
          <p className="text-slate-400 text-lg">Verify recruiter legitimacy before sharing personal information</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Search Section */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-1">
            <Card className="p-6 sticky top-24">
              <h2 className="text-lg font-semibold mb-4">Search Recruiter</h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="recruiter@company.com"
                    className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg px-4 py-2 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20"
                  />
                </div>

                <Button variant="secondary" size="md" className="w-full" onClick={handleSearch}>
                  Verify Now
                </Button>
              </div>

              {/* Info Box */}
              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <p className="text-xs text-blue-300">
                  🔒 We check domain legitimacy, SSL certificates, and fraud reports.
                </p>
              </div>
            </Card>
          </motion.div>

          {/* Results Section */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-3 space-y-6">
            {hasSearched && recruiter ? (
              <>
                {/* Status Card */}
                <Card className={`p-8 border ${statusConfig[recruiter.status].border}`}>
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h2 className="text-2xl font-bold text-white mb-2">{recruiter.name}</h2>
                      <p className="text-slate-400">{recruiter.company}</p>
                    </div>
                    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${statusConfig[recruiter.status].badge} border ${statusConfig[recruiter.status].border}`}>
                      {(() => {
                        const Icon = statusConfig[recruiter.status].icon;
                        return <Icon className={`h-5 w-5 ${statusConfig[recruiter.status].color}`} />;
                      })()}
                      <span className="font-semibold">{statusConfig[recruiter.status].label}</span>
                    </div>
                  </div>

                  {/* Trust Score */}
                  <div className="relative h-2 bg-slate-700/50 rounded-full overflow-hidden mb-6">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${recruiter.trustScore}%` }}
                      transition={{ duration: 1.5 }}
                      className={`h-full bg-gradient-to-r ${
                        recruiter.trustScore > 70
                          ? 'from-green-500 to-green-600'
                          : recruiter.trustScore > 40
                            ? 'from-yellow-500 to-yellow-600'
                            : 'from-red-500 to-red-600'
                      }`}
                    />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-slate-400">Trust Score</span>
                    <span className="text-lg font-bold text-white">{recruiter.trustScore}/100</span>
                  </div>
                </Card>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { icon: Calendar, label: 'Domain Age', value: `${recruiter.domainAge}y`, color: 'text-blue-400' },
                    { icon: Lock, label: 'SSL Status', value: recruiter.sslStatus ? 'Active' : 'Inactive', color: recruiter.sslStatus ? 'text-green-400' : 'text-red-400' },
                    { icon: AlertTriangle, label: 'Fraud Reports', value: recruiter.reports, color: recruiter.reports === 0 ? 'text-green-400' : 'text-red-400' },
                    { icon: TrendingUp, label: 'Verification', value: recruiter.verified ? 'Yes' : 'No', color: recruiter.verified ? 'text-green-400' : 'text-yellow-400' },
                  ].map((metric, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <Card className="p-4 text-center">
                        <metric.icon className={`h-6 w-6 mx-auto mb-2 ${metric.color}`} />
                        <div className="text-xs text-slate-400 mb-1">{metric.label}</div>
                        <div className="font-semibold text-white">{metric.value}</div>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {/* Details */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Recruiter Details</h3>
                  <div className="space-y-3">
                    {[
                      { label: 'Email', value: recruiter.email },
                      { label: 'Domain', value: recruiter.domain },
                      { label: 'Email Valid', value: 'Yes' },
                      { label: 'Domain SSL', value: recruiter.sslStatus ? 'Valid' : 'Invalid' },
                    ].map((item, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex justify-between items-center pb-3 border-b border-slate-700/30 last:border-0"
                      >
                        <span className="text-slate-400">{item.label}</span>
                        <span className="text-white font-medium">{item.value}</span>
                      </motion.div>
                    ))}
                  </div>
                </Card>

                {/* Status Messages */}
                {recruiter.status === 'verified' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 bg-green-500/10 border border-green-500/30 rounded-2xl"
                  >
                    <div className="flex items-start gap-4">
                      <CheckCircle2 className="h-6 w-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h4 className="font-semibold text-green-300 mb-1">Recruiter Verified</h4>
                        <p className="text-green-200/80 text-sm">
                          This recruiter has been verified and has no fraud reports. It should be safe to proceed.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {recruiter.status === 'suspicious' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 bg-yellow-500/10 border border-yellow-500/30 rounded-2xl"
                  >
                    <div className="flex items-start gap-4">
                      <AlertCircle className="h-6 w-6 text-yellow-400 flex-shrink-0 mt-1" />
                      <div>
                        <h4 className="font-semibold text-yellow-300 mb-1">Suspicious Activity</h4>
                        <p className="text-yellow-200/80 text-sm">
                          This recruiter has some warning signs. Verify their identity independently before sharing personal information.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {recruiter.status === 'blacklisted' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-6 bg-red-500/10 border border-red-500/30 rounded-2xl"
                  >
                    <div className="flex items-start gap-4">
                      <XCircle className="h-6 w-6 text-red-400 flex-shrink-0 mt-1" />
                      <div>
                        <h4 className="font-semibold text-red-300 mb-1">Blacklisted Recruiter</h4>
                        <p className="text-red-200/80 text-sm">
                          This recruiter has multiple fraud reports. We strongly advise avoiding contact and reporting this email if encountered.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Actions */}
                <div className="flex gap-4">
                  <Button variant="outline" size="md" className="flex-1">
                    Report Recruiter
                  </Button>
                  <Button variant="secondary" size="md" className="flex-1">
                    Save to List
                  </Button>
                </div>
              </>
            ) : (
              <Card className="p-12 text-center">
                <Globe className="h-16 w-16 mx-auto text-slate-600 mb-4" />
                <p className="text-slate-400 text-lg">Enter a recruiter email to verify their legitimacy</p>
              </Card>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
