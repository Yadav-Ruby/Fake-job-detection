import { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, Copy, Download, Shield, Link as LinkIcon, FileText, Image as ImageIcon } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

type TabType = 'url' | 'description' | 'screenshot';
type RiskLevel = 'safe' | 'warning' | 'danger';

export default function ScamChecker() {
  const [activeTab, setActiveTab] = useState<TabType>('url');
  const [input, setInput] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [riskLevel, setRiskLevel] = useState<RiskLevel>('safe');

  const handleSubmit = () => {
    if (input.trim()) {
      setHasSubmitted(true);
      // Simulate AI analysis with random risk level
      const levels: RiskLevel[] = ['safe', 'warning', 'danger'];
      setRiskLevel(levels[Math.floor(Math.random() * 3)]);
    }
  };

  const riskConfig = {
    safe: {
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/30',
      label: 'Safe',
      percentage: 5,
      icon: CheckCircle2,
    },
    warning: {
      color: 'from-yellow-500 to-yellow-600',
      bgColor: 'bg-yellow-500/10',
      borderColor: 'border-yellow-500/30',
      label: 'Suspicious',
      percentage: 72,
      icon: AlertCircle,
    },
    danger: {
      color: 'from-red-500 to-red-600',
      bgColor: 'bg-red-500/10',
      borderColor: 'border-red-500/30',
      label: 'Likely Scam',
      percentage: 95,
      icon: AlertCircle,
    },
  };

  const config = riskConfig[riskLevel];
  const Icon = config.icon;

  const fraudSignals = {
    warning: [
      'Generic email address detected',
      'New domain (created 6 months ago)',
      'Grammatical errors in job description',
      'Request for upfront payment',
    ],
    danger: [
      'Domain spoofing detected',
      'Known phishing infrastructure',
      'Multiple fraud reports (15+)',
      'Suspicious geographical mismatch',
      'Malware signature detected',
    ],
    safe: [
      'Verified company domain',
      'Long domain history (8+ years)',
      'Professional communication',
      'No payment requirements',
    ],
  };

  const signals = fraudSignals[riskLevel === 'warning' ? 'warning' : riskLevel === 'danger' ? 'danger' : 'safe'];

  const keywords = {
    warning: ['urgent', 'quick money', 'no experience needed', 'work from home'],
    danger: ['guaranteed income', 'wire transfer', 'bitcoin only', 'confidential'],
    safe: ['competitive salary', 'equal opportunity', 'benefits package', 'interview process'],
  };

  const susKeywords = keywords[riskLevel === 'warning' ? 'warning' : riskLevel === 'danger' ? 'danger' : 'safe'];

  return (
    <div className="min-h-screen py-12">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Scam Checker</h1>
          <p className="text-slate-400 text-lg">
            Paste a job link, description, or screenshot to analyze for scam indicators
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Section */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-1">
            <Card className="p-6 sticky top-24">
              <h2 className="text-lg font-semibold mb-4">Check for Scams</h2>

              {/* Tabs */}
              <div className="flex gap-2 mb-6 bg-slate-900/50 p-1 rounded-lg">
                {[
                  { id: 'url', icon: LinkIcon, label: 'URL' },
                  { id: 'description', icon: FileText, label: 'Text' },
                  { id: 'screenshot', icon: ImageIcon, label: 'Image' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as TabType)}
                    className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-all duration-200 text-sm font-medium ${
                      activeTab === tab.id
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'text-slate-400 hover:text-slate-300'
                    }`}
                  >
                    <tab.icon className="h-4 w-4" />
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Input Area */}
              <div className="space-y-4">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={
                    activeTab === 'url'
                      ? 'Paste job URL here...'
                      : activeTab === 'description'
                        ? 'Paste job description...'
                        : 'Upload screenshot...'
                  }
                  className="w-full h-32 bg-slate-900/50 border border-slate-700/50 rounded-lg p-4 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20 resize-none"
                />

                <Button variant="primary" size="md" className="w-full" onClick={handleSubmit}>
                  <Shield className="h-4 w-4" />
                  Analyze Now
                </Button>
              </div>

              {/* Info */}
              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <p className="text-xs text-blue-300">
                  💡 Your data is encrypted and never stored. Instant results powered by AI.
                </p>
              </div>
            </Card>
          </motion.div>

          {/* Results Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2 space-y-6"
          >
            {hasSubmitted ? (
              <>
                {/* Risk Score Ring */}
                <Card className="p-8">
                  <div className="flex flex-col items-center justify-center">
                    <div className="relative w-32 h-32 mb-6">
                      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="45" fill="none" stroke="#1e293b" strokeWidth="8" />
                        <motion.circle
                          cx="50"
                          cy="50"
                          r="45"
                          fill="none"
                          strokeWidth="8"
                          className={`stroke-current text-transparent`}
                          style={{
                            background: `linear-gradient(90deg, ${
                              riskLevel === 'safe'
                                ? '#10b981'
                                : riskLevel === 'warning'
                                  ? '#f59e0b'
                                  : '#ef4444'
                            })`,
                          }}
                          strokeDasharray={`${(config.percentage / 100) * 283} 283`}
                          initial={{ strokeDasharray: '0 283' }}
                          animate={{ strokeDasharray: `${(config.percentage / 100) * 283} 283` }}
                          transition={{ duration: 1.5 }}
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <div className={`text-3xl font-bold bg-gradient-to-r ${config.color} bg-clip-text text-transparent`}>
                            {config.percentage}%
                          </div>
                          <div className="text-xs text-slate-400">Risk Score</div>
                        </div>
                      </div>
                    </div>

                    <div className="text-center">
                      <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${config.bgColor} border ${config.borderColor} mb-4`}>
                        <Icon className={`h-5 w-5 ${riskLevel === 'safe' ? 'text-green-400' : riskLevel === 'warning' ? 'text-yellow-400' : 'text-red-400'}`} />
                        <span className={riskLevel === 'safe' ? 'text-green-300' : riskLevel === 'warning' ? 'text-yellow-300' : 'text-red-300'}>
                          {config.label}
                        </span>
                      </div>

                      <p className="text-slate-400 text-sm max-w-sm">
                        {riskLevel === 'safe'
                          ? 'This appears to be a legitimate job opportunity. Proceed with confidence.'
                          : riskLevel === 'warning'
                            ? 'Some warning signs detected. Exercise caution and verify independently.'
                            : 'Multiple scam indicators detected. We strongly recommend avoiding this.'}
                      </p>
                    </div>
                  </div>
                </Card>

                {/* Fraud Signals */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-red-400" />
                    Fraud Signals Detected
                  </h3>
                  <ul className="space-y-3">
                    {signals.map((signal, i) => (
                      <motion.li
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex items-start gap-3"
                      >
                        <div className={`mt-1 h-2 w-2 rounded-full flex-shrink-0 ${riskLevel === 'safe' ? 'bg-green-400' : riskLevel === 'warning' ? 'bg-yellow-400' : 'bg-red-400'}`} />
                        <span className="text-slate-300 text-sm">{signal}</span>
                      </motion.li>
                    ))}
                  </ul>
                </Card>

                {/* Suspicious Keywords */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Detected Keywords</h3>
                  <div className="flex flex-wrap gap-2">
                    {susKeywords.map((keyword, i) => (
                      <motion.span
                        key={i}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          riskLevel === 'safe'
                            ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                            : riskLevel === 'warning'
                              ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30'
                              : 'bg-red-500/20 text-red-300 border border-red-500/30'
                        }`}
                      >
                        {keyword}
                      </motion.span>
                    ))}
                  </div>
                </Card>

                {/* Actions */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Button variant="outline" size="md" className="w-full">
                    <Copy className="h-4 w-4" />
                    Copy Results
                  </Button>
                  <Button variant="outline" size="md" className="w-full">
                    <Download className="h-4 w-4" />
                    Download Report
                  </Button>
                  <Button variant="secondary" size="md" className="w-full">
                    Report Scam
                  </Button>
                </div>
              </>
            ) : (
              <Card className="p-12 text-center">
                <Shield className="h-16 w-16 mx-auto text-slate-600 mb-4" />
                <p className="text-slate-400 text-lg">
                  Submit a URL, job description, or screenshot to get started
                </p>
              </Card>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
