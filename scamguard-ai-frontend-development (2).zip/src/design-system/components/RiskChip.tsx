import { ReactNode } from 'react';
import { motion } from 'framer-motion';

type RiskLevel = 'safe' | 'low' | 'medium' | 'high' | 'critical' | 'verified' | 'suspicious' | 'blacklisted' | 'warning' | 'danger';
type ChipSize = 'sm' | 'md' | 'lg';

interface RiskChipProps {
  level: RiskLevel;
  size?: ChipSize;
  label?: string;
  icon?: ReactNode;
  removable?: boolean;
  onRemove?: () => void;
  className?: string;
  animated?: boolean;
}

const riskStyles: Record<RiskLevel, { bg: string; text: string; border: string; icon?: string }> = {
  safe: {
    bg: 'bg-green-500/20',
    text: 'text-green-300',
    border: 'border-green-500/30',
  },
  low: {
    bg: 'bg-green-500/20',
    text: 'text-green-300',
    border: 'border-green-500/30',
  },
  medium: {
    bg: 'bg-yellow-500/20',
    text: 'text-yellow-300',
    border: 'border-yellow-500/30',
  },
  high: {
    bg: 'bg-orange-500/20',
    text: 'text-orange-300',
    border: 'border-orange-500/30',
  },
  critical: {
    bg: 'bg-red-500/20',
    text: 'text-red-300',
    border: 'border-red-500/30',
  },
  verified: {
    bg: 'bg-green-500/20',
    text: 'text-green-300',
    border: 'border-green-500/30',
  },
  suspicious: {
    bg: 'bg-yellow-500/20',
    text: 'text-yellow-300',
    border: 'border-yellow-500/30',
  },
  blacklisted: {
    bg: 'bg-red-500/20',
    text: 'text-red-300',
    border: 'border-red-500/30',
  },
  warning: {
    bg: 'bg-yellow-500/20',
    text: 'text-yellow-300',
    border: 'border-yellow-500/30',
  },
  danger: {
    bg: 'bg-red-500/20',
    text: 'text-red-300',
    border: 'border-red-500/30',
  },
};

const sizeStyles: Record<ChipSize, string> = {
  sm: 'px-2 py-1 text-xs font-semibold',
  md: 'px-3 py-1.5 text-sm font-semibold',
  lg: 'px-4 py-2 text-base font-bold',
};

const riskLabels: Record<RiskLevel, string> = {
  safe: '✓ Safe',
  low: '△ Low Risk',
  medium: '⚠ Medium Risk',
  high: '⚠ High Risk',
  critical: '✕ Critical',
  verified: '✓ Verified',
  suspicious: '△ Suspicious',
  blacklisted: '✕ Blacklisted',
  warning: '⚠ Warning',
  danger: '✕ Danger',
};

export default function RiskChip({
  level,
  size = 'md',
  label,
  icon,
  removable = false,
  onRemove,
  className = '',
  animated = true,
}: RiskChipProps) {
  const style = riskStyles[level];
  const displayLabel = label || riskLabels[level];

  return (
    <motion.div
      initial={animated ? { opacity: 0, scale: 0.9 } : {}}
      animate={animated ? { opacity: 1, scale: 1 } : {}}
      exit={animated ? { opacity: 0, scale: 0.9 } : {}}
      className={`inline-flex items-center gap-2 rounded-full border font-inter transition-all duration-200 ${style.bg} ${style.text} ${style.border} ${sizeStyles[size]} ${className}`}
    >
      {icon ? (
        <span className="flex items-center">{icon}</span>
      ) : (
        <div className={`w-2 h-2 rounded-full ${
          level === 'safe' || level === 'verified'
            ? 'bg-green-400'
            : level === 'medium' || level === 'suspicious'
              ? 'bg-yellow-400'
              : 'bg-red-400'
        }`} />
      )}
      <span>{displayLabel}</span>
      {removable && (
        <button
          onClick={onRemove}
          className="ml-1 hover:opacity-70 transition-opacity flex items-center"
          aria-label="Remove"
        >
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path
              fillRule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      )}
    </motion.div>
  );
}
