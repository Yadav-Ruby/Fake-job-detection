import { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, Upload, Send } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

type FormStep = 'form' | 'success';

export default function ReportScam() {
  const [step, setStep] = useState<FormStep>('form');
  const [formData, setFormData] = useState({
    scamType: '',
    title: '',
    description: '',
    email: '',
    website: '',
    screenshot: null as string | null,
    contactMethod: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData((prev) => ({
          ...prev,
          screenshot: event.target?.result as string,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.scamType && formData.title && formData.description) {
      setStep('success');
      setTimeout(() => {
        setStep('form');
        setFormData({
          scamType: '',
          title: '',
          description: '',
          email: '',
          website: '',
          screenshot: null,
          contactMethod: '',
        });
      }, 5000);
    }
  };

  return (
    <div className="min-h-screen py-12">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Report a Scam</h1>
          <p className="text-slate-400 text-lg">
            Help us protect other students by reporting suspicious job offers and scams
          </p>
        </motion.div>

        {step === 'form' ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="p-8 lg:p-10">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Scam Type */}
                <div>
                  <label className="block text-lg font-semibold text-white mb-3">What type of scam is this? *</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      'Fake Job',
                      'Recruiter Scam',
                      'Registration Fee',
                      'Phishing',
                      'WhatsApp/Telegram',
                      'Other',
                    ].map((type) => (
                      <label key={type} className="relative cursor-pointer">
                        <input
                          type="radio"
                          name="scamType"
                          value={type}
                          checked={formData.scamType === type}
                          onChange={handleChange}
                          className="sr-only"
                        />
                        <div
                          className={`px-4 py-3 rounded-lg border-2 transition-all duration-200 font-medium text-center ${
                            formData.scamType === type
                              ? 'border-red-500 bg-red-500/10 text-red-300'
                              : 'border-slate-700/50 bg-slate-800/30 text-slate-300 hover:border-slate-600'
                          }`}
                        >
                          {type}
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Title */}
                <div>
                  <label className="block text-lg font-semibold text-white mb-3">
                    Brief Title *
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    placeholder="e.g., Fake Amazon Internship Offer"
                    className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20"
                    required
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-lg font-semibold text-white mb-3">
                    Detailed Description *
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Describe what happened, any suspicious details, and how you identified it as a scam..."
                    className="w-full h-40 bg-slate-900/50 border border-slate-700/50 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20 resize-none"
                    required
                  />
                </div>

                {/* Contact Information */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-lg font-semibold text-white mb-3">Email (Optional)</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your@email.com"
                      className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20"
                    />
                    <p className="text-xs text-slate-500 mt-2">So we can follow up if needed</p>
                  </div>

                  <div>
                    <label className="block text-lg font-semibold text-white mb-3">Website/URL (Optional)</label>
                    <input
                      type="text"
                      name="website"
                      value={formData.website}
                      onChange={handleChange}
                      placeholder="https://..."
                      className="w-full bg-slate-900/50 border border-slate-700/50 rounded-lg px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20"
                    />
                  </div>
                </div>

                {/* File Upload */}
                <div>
                  <label className="block text-lg font-semibold text-white mb-3">Upload Screenshot (Optional)</label>
                  <div className="relative border-2 border-dashed border-slate-700/50 rounded-lg p-8 text-center hover:border-slate-600 transition-colors cursor-pointer group">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="sr-only"
                      id="file-upload"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-2">
                      <Upload className="h-8 w-8 text-slate-500 group-hover:text-slate-400" />
                      <span className="text-slate-300">
                        {formData.screenshot ? 'Screenshot uploaded ✓' : 'Click to upload screenshot'}
                      </span>
                      <span className="text-xs text-slate-500">PNG, JPG, GIF up to 5MB</span>
                    </label>
                  </div>
                </div>

                {/* Consent */}
                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <div className="flex gap-3">
                    <AlertCircle className="h-5 w-5 text-blue-400 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-blue-300">
                      Your report will be kept confidential and used to improve our detection model and protect other students.
                    </p>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex gap-4">
                  <Button variant="primary" size="lg" className="flex-1" type="submit">
                    <Send className="h-5 w-5" />
                    Submit Report
                  </Button>
                  <Button variant="outline" size="lg" className="flex-1">
                    Save Draft
                  </Button>
                </div>
              </form>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
          >
            <Card className="p-12 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                className="mb-6"
              >
                <div className="h-16 w-16 mx-auto rounded-full bg-green-500/20 border border-green-500/30 flex items-center justify-center">
                  <CheckCircle2 className="h-8 w-8 text-green-400" />
                </div>
              </motion.div>

              <h2 className="text-3xl font-bold text-white mb-3">Thank You!</h2>
              <p className="text-lg text-slate-400 mb-8 max-w-md mx-auto">
                Your report has been successfully submitted. We've added this information to our database to help protect other students.
              </p>

              <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg mb-8">
                <p className="text-sm text-green-300">
                  ✓ Report ID: #SR-{Math.random().toString(36).substr(2, 9).toUpperCase()}
                </p>
              </div>

              <div className="space-y-3">
                <p className="text-slate-300 font-medium">What happens next?</p>
                <ul className="text-slate-400 text-sm space-y-2 text-left max-w-md mx-auto">
                  <li className="flex gap-2">
                    <span className="text-green-400">✓</span>
                    <span>Our team will review your report within 24 hours</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-400">✓</span>
                    <span>We'll add it to our scam database</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-green-400">✓</span>
                    <span>Our AI model will use it to improve detection</span>
                  </li>
                </ul>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Help Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-12"
        >
          <Card className="p-8">
            <h3 className="text-2xl font-bold text-white mb-6">How to Report Effectively</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  title: 'Be Specific',
                  desc: 'Include exact URLs, email addresses, and details about the scam attempt',
                },
                {
                  title: 'Include Evidence',
                  desc: 'Screenshots and message records help us verify and confirm scams',
                },
                {
                  title: 'Stay Safe',
                  desc: 'Never share your personal passwords or sensitive financial information',
                },
              ].map((tip, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.1 }}
                >
                  <div className="space-y-2">
                    <p className="font-semibold text-white">{tip.title}</p>
                    <p className="text-slate-400 text-sm">{tip.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
