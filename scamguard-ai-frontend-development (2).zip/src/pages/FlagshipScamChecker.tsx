import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Shield,
  AlertCircle,
  CheckCircle2,
  Copy,
  Download,
  Share2,
  Zap,
  Clock,
  Eye,
  Lightbulb,
  ChevronDown,
} from 'lucide-react';
import Card from '../design-system/components/Card';
import ScoreRing from '../design-system/components/ScoreRing';
import RiskChip from '../design-system/components/RiskChip';
import Badge from '../design-system/components/Badge';

type AnalysisStatus = 'idle' | 'analyzing' | 'complete';
type RiskLevel = 'safe' | 'warning' | 'danger';

interface FraudSignal {
  signal: string;
  confidence: number;
  category: string;
  severity: 'low' | 'medium' | 'high';
}

interface TimelineEvent {
  time: string;
  event: string;
  risk: string;
  color: string;
}

export default function FlagshipScamChecker() {
  const [analysisStatus, setAnalysisStatus] = useState<AnalysisStatus>('idle');
  const [selectedInput, setSelectedInput] = useState('fake-listing');
  const [expandedSignal, setExpandedSignal] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  // Realistic mock data
  const mockData = {
    'fake-listing': {
      riskLevel: 'danger' as RiskLevel,
      riskScore: 92,
      title: 'Amazon Remote Data Entry Position',
      url: 'amazon-careers-2024.tk',
      analysis: `Our AI detected multiple sophisticated fraud indicators in this listing. The email domain spoofing (amazon-careers-2024.tk instead of amazon.com), combined with urgency tactics ("Hire immediately!") and requests for upfront information typically indicate a recruiter scam. The salary range ($8,500/month) is unrealistic for the position, and the lack of specific job responsibilities is a classic red flag.`,
      fraudSignals: [
        {
          signal: 'Domain Spoofing Detected',
          confidence: 98,
          category: 'Email Authenticity',
          severity: 'high',
        },
        {
          signal: 'Unrealistic Salary Range',
          confidence: 95,
          category: 'Job Details',
          severity: 'high',
        },
        {
          signal: 'Urgency Language',
          confidence: 87,
          category: 'Psychological Tactics',
          severity: 'high',
        },
        {
          signal: 'Generic Job Description',
          confidence: 82,
          category: 'Content Analysis',
          severity: 'medium',
        },
        {
          signal: 'Missing Contact Information',
          confidence: 79,
          category: 'Legitimacy Markers',
          severity: 'medium',
        },
        {
          signal: 'No Company Verification',
          confidence: 91,
          category: 'Registration Check',
          severity: 'high',
        },
      ] as FraudSignal[],
      keywords: [
        'URGENT',
        'IMMEDIATE HIRE',
        'NO EXPERIENCE NEEDED',
        'WORK FROM HOME',
        'GUARANTEED',
        'HIGH SALARY',
        'LIMITED TIME',
        'NO INTERVIEW',
      ],
      timeline: [
        {
          time: '0:00',
          event: 'Domain name registered 2 weeks ago',
          risk: 'CRITICAL',
          color: 'text-red-400',
        },
        {
          time: '0:15',
          event: 'Email spoofing algorithm detected',
          risk: 'CRITICAL',
          color: 'text-red-400',
        },
        {
          time: '0:32',
          event: 'Similar scams identified in database',
          risk: 'HIGH',
          color: 'text-orange-400',
        },
        {
          time: '0:48',
          event: 'Machine learning model flagged pattern',
          risk: 'HIGH',
          color: 'text-orange-400',
        },
        {
          time: '1:02',
          event: 'Cross-referenced with 500+ known scams',
          risk: 'CRITICAL',
          color: 'text-red-400',
        },
        {
          time: '1:15',
          event: 'Final risk assessment: LIKELY SCAM',
          risk: 'CRITICAL',
          color: 'text-red-400',
        },
      ] as TimelineEvent[],
    },
    'suspicious-recruiter': {
      riskLevel: 'warning' as RiskLevel,
      riskScore: 68,
      title: 'Junior Developer - Startup (via WhatsApp)',
      url: 'whatsapp-contact',
      analysis: `This opportunity shows several warning signs that warrant caution. While not definitively a scam, the medium (WhatsApp instead of official channels), vague job description, and lack of company verification are concerning. The salary is competitive but needs independent verification. Recommend reaching out to the company through their official website before proceeding.`,
      fraudSignals: [
        {
          signal: 'Unofficial Communication Channel',
          confidence: 92,
          category: 'Contact Method',
          severity: 'high',
        },
        {
          signal: 'Vague Company Details',
          confidence: 78,
          category: 'Organization Info',
          severity: 'medium',
        },
        {
          signal: 'Pressure to Decide Quickly',
          confidence: 71,
          category: 'Psychological Tactics',
          severity: 'medium',
        },
        {
          signal: 'No Official Email Address',
          confidence: 85,
          category: 'Professional Standards',
          severity: 'high',
        },
        {
          signal: 'Skipped Technical Interview',
          confidence: 64,
          category: 'Hiring Process',
          severity: 'medium',
        },
      ] as FraudSignal[],
      keywords: [
        'QUICK DECISION',
        'FLEXIBLE',
        'STARTUP',
        'REMOTE',
        'FAST PROCESS',
        'CASUAL',
        'INFORMAL',
      ],
      timeline: [
        {
          time: '0:00',
          event: 'Analyzed communication method',
          risk: 'MEDIUM',
          color: 'text-yellow-400',
        },
        {
          time: '0:22',
          event: 'Checked company registration',
          risk: 'MEDIUM',
          color: 'text-yellow-400',
        },
        {
          time: '0:45',
          event: 'Verified email domain status',
          risk: 'MEDIUM',
          color: 'text-yellow-400',
        },
        {
          time: '1:10',
          event: 'Compared with legitimate startups',
          risk: 'MEDIUM',
          color: 'text-yellow-400',
        },
        {
          time: '1:38',
          event: 'Final assessment: SUSPICIOUS',
          risk: 'MEDIUM',
          color: 'text-yellow-400',
        },
      ] as TimelineEvent[],
    },
    'legitimate': {
      riskLevel: 'safe' as RiskLevel,
      riskScore: 8,
      title: 'Senior Software Engineer - Google',
      url: 'careers.google.com',
      analysis: `This is a legitimate job posting from Google. The official domain (careers.google.com), professional presentation, comprehensive job description, and standard application process all indicate authenticity. Google's established reputation and verified company information provide strong legitimacy signals. Proceed with confidence in applying through official channels.`,
      fraudSignals: [
        {
          signal: 'Verified Company Domain',
          confidence: 99,
          category: 'Domain Authentication',
          severity: 'low',
        },
        {
          signal: 'Professional Job Description',
          confidence: 96,
          category: 'Content Quality',
          severity: 'low',
        },
        {
          signal: 'Realistic Requirements',
          confidence: 94,
          category: 'Role Specifications',
          severity: 'low',
        },
        {
          signal: 'Formal Application Process',
          confidence: 98,
          category: 'Hiring Procedures',
          severity: 'low',
        },
      ] as FraudSignal[],
      keywords: [
        'OPPORTUNITIES',
        'GROW',
        'IMPACT',
        'CAREER',
        'INNOVATION',
        'CULTURE',
        'BENEFITS',
      ],
      timeline: [
        {
          time: '0:00',
          event: 'Domain verified: careers.google.com',
          risk: 'SAFE',
          color: 'text-green-400',
        },
        {
          time: '0:18',
          event: 'SSL certificate validated',
          risk: 'SAFE',
          color: 'text-green-400',
        },
        {
          time: '0:35',
          event: 'Company registration verified',
          risk: 'SAFE',
          color: 'text-green-400',
        },
        {
          time: '0:52',
          event: 'Cross-checked against verified database',
          risk: 'SAFE',
          color: 'text-green-400',
        },
        {
          time: '1:10',
          event: 'Final assessment: LEGITIMATE',
          risk: 'SAFE',
          color: 'text-green-400',
        },
      ] as TimelineEvent[],
    },
  };

  const currentData = mockData[selectedInput as keyof typeof mockData];

  const handleAnalyze = async () => {
    setAnalysisStatus('analyzing');
    await new Promise((resolve) => setTimeout(resolve, 2500));
    setAnalysisStatus('complete');
  };

  const handleDownload = () => {
    const reportContent = `
ScamGuard AI - Scam Analysis Report
Generated: ${new Date().toLocaleString()}

Title: ${currentData.title}
URL/Source: ${currentData.url}
Risk Score: ${currentData.riskScore}/100
Risk Level: ${currentData.riskLevel.toUpperCase()}

AI EXPLANATION:
${currentData.analysis}

FRAUD SIGNALS:
${currentData.fraudSignals
  .map((signal) => `- ${signal.signal} (${signal.confidence}% confidence)`)
  .join('\n')}

SUSPICIOUS KEYWORDS:
${currentData.keywords.join(', ')}

RECOMMENDATION:
${
  currentData.riskLevel === 'danger'
    ? 'AVOID THIS OPPORTUNITY - Multiple critical fraud indicators detected.'
    : currentData.riskLevel === 'warning'
      ? 'CAUTION ADVISED - Verify independently through official channels.'
      : 'APPEARS LEGITIMATE - Standard precautions recommended.'
}

For more information, visit ScamGuard AI at https://scamguard.ai
    `;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(reportContent));
    element.setAttribute('download', `scam-report-${Date.now()}.txt`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentData.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
            Scam <span className="bg-gradient-to-r from-red-400 to-red-600 bg-clip-text text-transparent">Checker</span>
          </h1>
          <p className="text-xl text-slate-400">
            AI-powered analysis of job postings, emails, and recruiter communications
          </p>
        </motion.div>

        {/* Demo Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-12"
        >
          <Card className="p-6 md:p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <Lightbulb className="h-6 w-6 text-yellow-400" />
              Try Demo Examples
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                {
                  id: 'fake-listing',
                  label: '⚠️ Clear Scam',
                  desc: 'Amazon data entry (92% risk)',
                },
                {
                  id: 'suspicious-recruiter',
                  label: '🟡 Suspicious',
                  desc: 'WhatsApp recruiter (68% risk)',
                },
                {
                  id: 'legitimate',
                  label: '✓ Legitimate',
                  desc: 'Google careers (8% risk)',
                },
              ].map((demo) => (
                <motion.button
                  key={demo.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setSelectedInput(demo.id);
                    setAnalysisStatus('idle');
                  }}
                  className={`p-4 rounded-xl border-2 transition-all duration-300 text-left ${
                    selectedInput === demo.id
                      ? 'border-red-500 bg-red-500/20'
                      : 'border-slate-700 bg-slate-800/30 hover:border-slate-600'
                  }`}
                >
                  <p className="font-bold text-white">{demo.label}</p>
                  <p className="text-sm text-slate-400">{demo.desc}</p>
                </motion.button>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleAnalyze}
              disabled={analysisStatus === 'analyzing'}
              className="w-full mt-6 py-3 rounded-lg bg-gradient-to-r from-red-500 to-red-600 text-white font-semibold hover:from-red-600 hover:to-red-700 transition-all duration-200 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {analysisStatus === 'analyzing' ? (
                <>
                  <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  Analyzing with AI...
                </>
              ) : (
                <>
                  <Zap className="h-5 w-5" />
                  Start Analysis
                </>
              )}
            </motion.button>
          </Card>
        </motion.div>

        {/* Results Section */}
        <AnimatePresence>
          {analysisStatus === 'complete' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              {/* Risk Score Section */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <Card className="p-8 md:p-12 text-center">
                  <h2 className="text-3xl font-bold text-white mb-8">Risk Assessment</h2>

                  <div className="flex flex-col md:flex-row items-center justify-center gap-12">
                    {/* Risk Ring */}
                    <motion.div
                      initial={{ scale: 0.8 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.6, delay: 0.2 }}
                    >
                      <ScoreRing
                        score={currentData.riskScore}
                        level={currentData.riskLevel}
                        size="lg"
                        label="Risk Score"
                        showPercentage={true}
                      />
                    </motion.div>

                    {/* Details */}
                    <motion.div
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.6, delay: 0.3 }}
                      className="text-left max-w-md"
                    >
                      <div className="mb-6">
                        <RiskChip level={currentData.riskLevel} size="lg" />
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-semibold text-slate-300 mb-2">Title</h3>
                          <p className="text-white">{currentData.title}</p>
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-slate-300 mb-2">Source</h3>
                          <div className="flex items-center gap-2">
                            <p className="text-white font-mono text-sm">{currentData.url}</p>
                            <motion.button
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={handleCopy}
                              className="p-2 rounded-lg hover:bg-slate-700/50 transition-colors"
                            >
                              <Copy className={`h-4 w-4 ${copied ? 'text-green-400' : 'text-slate-400'}`} />
                            </motion.button>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-2 pt-4">
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={handleDownload}
                            className="flex-1 px-4 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white hover:border-slate-600 transition-colors flex items-center justify-center gap-2"
                          >
                            <Download className="h-4 w-4" />
                            Download
                          </motion.button>
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="flex-1 px-4 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white hover:border-slate-600 transition-colors flex items-center justify-center gap-2"
                          >
                            <Share2 className="h-4 w-4" />
                            Share
                          </motion.button>
                        </div>
                      </div>
                    </motion.div>
                  </div>
                </Card>
              </motion.div>

              {/* AI Explanation */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    <Eye className="h-6 w-6 text-blue-400" />
                    AI Explanation
                  </h2>
                  <p className="text-slate-300 leading-relaxed text-lg">{currentData.analysis}</p>
                </Card>
              </motion.div>

              {/* Fraud Signals Breakdown */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                    <AlertCircle className="h-6 w-6 text-red-400" />
                    Fraud Signals Detected ({currentData.fraudSignals.length})
                  </h2>

                  <div className="space-y-3">
                    {currentData.fraudSignals.map((signal, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: 0.3 + index * 0.05 }}
                        className="rounded-lg border border-slate-700/50 overflow-hidden"
                      >
                        <motion.button
                          onClick={() => setExpandedSignal(expandedSignal === index ? null : index)}
                          className="w-full px-6 py-4 bg-slate-800/40 hover:bg-slate-800/60 transition-colors flex items-center justify-between"
                        >
                          <div className="flex items-center gap-4 flex-1 text-left">
                            <div
                              className={`w-2 h-8 rounded-full ${
                                signal.severity === 'high'
                                  ? 'bg-red-500'
                                  : signal.severity === 'medium'
                                    ? 'bg-yellow-500'
                                    : 'bg-blue-500'
                              }`}
                            />
                            <div className="flex-1">
                              <p className="font-semibold text-white">{signal.signal}</p>
                              <p className="text-sm text-slate-400">{signal.category}</p>
                            </div>
                            <Badge variant={signal.severity === 'high' ? 'danger' : 'warning'} size="sm">
                              {signal.confidence}%
                            </Badge>
                          </div>
                          <motion.div
                            initial={{ rotate: 0 }}
                            animate={{ rotate: expandedSignal === index ? 180 : 0 }}
                            className="ml-4"
                          >
                            <ChevronDown className="h-5 w-5 text-slate-400" />
                          </motion.div>
                        </motion.button>

                        <AnimatePresence>
                          {expandedSignal === index && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.3 }}
                              className="px-6 py-4 bg-slate-900/50 border-t border-slate-700/50"
                            >
                              <p className="text-slate-300 text-sm leading-relaxed">
                                {`This signal indicates a ${signal.severity} severity issue. `}
                                {signal.severity === 'high' &&
                                  'This is a critical indicator that should not be ignored.'}
                                {signal.severity === 'medium' && 'This warrants careful consideration and verification.'}
                                {signal.severity === 'low' &&
                                  'This is a minor concern in the overall assessment.'}
                              </p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              </motion.div>

              {/* Suspicious Keywords */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                    <Zap className="h-6 w-6 text-yellow-400" />
                    Suspicious Keywords
                  </h2>

                  <div className="flex flex-wrap gap-3">
                    {currentData.keywords.map((keyword, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: 0.4 + index * 0.04 }}
                      >
                        <Badge
                          variant={
                            currentData.riskLevel === 'danger'
                              ? 'danger'
                              : currentData.riskLevel === 'warning'
                                ? 'warning'
                                : 'success'
                          }
                          size="md"
                        >
                          {keyword}
                        </Badge>
                      </motion.div>
                    ))}
                  </div>

                  <p className="text-slate-400 text-sm mt-6">
                    These keywords are commonly found in scam postings. While individual keywords are not indicators, their combination suggests suspicious intent.
                  </p>
                </Card>
              </motion.div>

              {/* NLP Analysis Timeline */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
                    <Clock className="h-6 w-6 text-purple-400" />
                    NLP Analysis Timeline
                  </h2>

                  <div className="space-y-6">
                    {currentData.timeline.map((event, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: 0.5 + index * 0.08 }}
                        className="flex items-start gap-4"
                      >
                        {/* Timeline Dot */}
                        <div className="relative flex flex-col items-center">
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ duration: 0.3, delay: 0.6 + index * 0.08 }}
                            className={`w-4 h-4 rounded-full border-2 ${
                              event.risk === 'CRITICAL'
                                ? 'border-red-500 bg-red-500/20'
                                : event.risk === 'HIGH'
                                  ? 'border-orange-500 bg-orange-500/20'
                                  : event.risk === 'MEDIUM'
                                    ? 'border-yellow-500 bg-yellow-500/20'
                                    : 'border-green-500 bg-green-500/20'
                            }`}
                          />
                          {index !== currentData.timeline.length - 1 && (
                            <div className="w-1 h-12 bg-gradient-to-b from-slate-600 to-slate-700 my-1" />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 pt-1">
                          <div className="flex items-center gap-3 mb-1">
                            <span className="text-sm font-mono text-slate-400">{event.time}</span>
                            <span className={`text-xs font-bold ${event.color}`}>{event.risk}</span>
                          </div>
                          <p className="text-slate-300">{event.event}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              </motion.div>

              {/* Recommendation Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <Card
                  className={`p-8 border-l-4 ${
                    currentData.riskLevel === 'danger'
                      ? 'border-l-red-500 bg-red-500/5'
                      : currentData.riskLevel === 'warning'
                        ? 'border-l-yellow-500 bg-yellow-500/5'
                        : 'border-l-green-500 bg-green-500/5'
                  }`}
                >
                  <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    {currentData.riskLevel === 'danger' ? (
                      <>
                        <Shield className="h-6 w-6 text-red-400" />
                        <span>Strong Warning</span>
                      </>
                    ) : currentData.riskLevel === 'warning' ? (
                      <>
                        <AlertCircle className="h-6 w-6 text-yellow-400" />
                        <span>Proceed with Caution</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-6 w-6 text-green-400" />
                        <span>Appears Legitimate</span>
                      </>
                    )}
                  </h2>

                  <p className="text-slate-300 text-lg leading-relaxed">
                    {currentData.riskLevel === 'danger'
                      ? 'Based on comprehensive analysis, this opportunity exhibits multiple critical fraud indicators. We strongly recommend avoiding this posting and reporting it to the appropriate authorities. Do not provide any personal information or engage with this contact.'
                      : currentData.riskLevel === 'warning'
                        ? 'This opportunity shows some warning signs that require verification. Before proceeding, verify the company through official channels, check with the hiring manager through the company website, and avoid sharing sensitive personal information until you can confirm legitimacy.'
                        : 'This opportunity appears legitimate based on our analysis. Standard job application precautions are recommended. Always verify company details independently and never pay upfront fees for job applications.'}
                  </p>

                  {currentData.riskLevel !== 'safe' && (
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="mt-6 px-6 py-2 bg-red-500/20 border border-red-500/30 text-red-300 rounded-lg hover:bg-red-500/30 transition-colors flex items-center gap-2"
                    >
                      <AlertCircle className="h-4 w-4" />
                      Report This Scam
                    </motion.button>
                  )}
                </Card>
              </motion.div>

              {/* Next Steps */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.7 }}
              >
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-white mb-6">Next Steps</h2>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      {
                        number: 1,
                        title: 'Verify Independently',
                        desc: 'Visit the official company website and verify this job posting independently.',
                      },
                      {
                        number: 2,
                        title: 'Check Contact Info',
                        desc: 'Always use official contact information from the company website, not provided links.',
                      },
                      {
                        number: 3,
                        title: 'Trust Your Instincts',
                        desc: 'If something feels off, it probably is. Take time to verify before proceeding.',
                      },
                    ].map((step, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: 0.7 + index * 0.1 }}
                        className="p-6 rounded-lg bg-slate-800/30 border border-slate-700/50"
                      >
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center text-white font-bold mb-4">
                          {step.number}
                        </div>
                        <h3 className="font-semibold text-white mb-2">{step.title}</h3>
                        <p className="text-slate-400 text-sm">{step.desc}</p>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Idle State */}
        {analysisStatus === 'idle' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="text-center py-12"
          >
            <div className="inline-flex items-center justify-center h-24 w-24 rounded-2xl bg-slate-800/40 border border-slate-700/50 mb-6">
              <Shield className="h-12 w-12 text-slate-600" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Select a demo or analyze your own</h2>
            <p className="text-slate-400">Choose one of the example cases above to see ScamGuard AI in action</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
