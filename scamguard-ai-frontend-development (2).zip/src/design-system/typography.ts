/**
 * ScamGuard AI - Typography System
 * Font sizes, weights, and line heights
 */

export const typography = {
  // Font Family
  fontFamily: {
    primary: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    mono: '"Fira Code", "Monaco", monospace',
  },

  // Font Sizes
  fontSize: {
    xs: '0.75rem', // 12px
    sm: '0.875rem', // 14px
    base: '1rem', // 16px
    lg: '1.125rem', // 18px
    xl: '1.25rem', // 20px
    '2xl': '1.5rem', // 24px
    '3xl': '1.875rem', // 30px
    '4xl': '2.25rem', // 36px
    '5xl': '3rem', // 48px
    '6xl': '3.75rem', // 60px
    '7xl': '4.5rem', // 72px
  },

  // Font Weights
  fontWeight: {
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
  },

  // Line Heights
  lineHeight: {
    tight: 1.1,
    snug: 1.25,
    normal: 1.5,
    relaxed: 1.625,
    loose: 2,
  },

  // Letter Spacing
  letterSpacing: {
    tighter: '-0.05em',
    tight: '-0.025em',
    normal: '0em',
    wide: '0.025em',
    wider: '0.05em',
    widest: '0.1em',
  },

  // Typography Scales (Pre-composed)
  scales: {
    // Display (Hero/Landing)
    displayLarge: {
      fontSize: '3.75rem', // 60px
      fontWeight: 700,
      lineHeight: 1.1,
      letterSpacing: '-0.025em',
    },
    displayMedium: {
      fontSize: '3rem', // 48px
      fontWeight: 700,
      lineHeight: 1.1,
      letterSpacing: '-0.025em',
    },
    displaySmall: {
      fontSize: '2.25rem', // 36px
      fontWeight: 700,
      lineHeight: 1.25,
      letterSpacing: '-0.025em',
    },

    // Heading
    heading1: {
      fontSize: '2.25rem', // 36px
      fontWeight: 700,
      lineHeight: 1.25,
      letterSpacing: '-0.025em',
    },
    heading2: {
      fontSize: '1.875rem', // 30px
      fontWeight: 700,
      lineHeight: 1.25,
      letterSpacing: '-0.025em',
    },
    heading3: {
      fontSize: '1.5rem', // 24px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '-0.025em',
    },
    heading4: {
      fontSize: '1.25rem', // 20px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '0em',
    },

    // Subheading
    subheadingLarge: {
      fontSize: '1.125rem', // 18px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '0em',
    },
    subheadingMedium: {
      fontSize: '1rem', // 16px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '0em',
    },
    subheadingSmall: {
      fontSize: '0.875rem', // 14px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '0.025em',
    },

    // Body
    bodyLarge: {
      fontSize: '1rem', // 16px
      fontWeight: 400,
      lineHeight: 1.625,
      letterSpacing: '0em',
    },
    bodyMedium: {
      fontSize: '0.875rem', // 14px
      fontWeight: 400,
      lineHeight: 1.625,
      letterSpacing: '0em',
    },
    bodySmall: {
      fontSize: '0.75rem', // 12px
      fontWeight: 400,
      lineHeight: 1.5,
      letterSpacing: '0em',
    },

    // Label
    labelLarge: {
      fontSize: '0.875rem', // 14px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '0.025em',
    },
    labelMedium: {
      fontSize: '0.75rem', // 12px
      fontWeight: 600,
      lineHeight: 1.5,
      letterSpacing: '0.05em',
    },
    labelSmall: {
      fontSize: '0.625rem', // 10px
      fontWeight: 700,
      lineHeight: 1.5,
      letterSpacing: '0.1em',
      textTransform: 'uppercase' as const,
    },

    // Code
    codeLarge: {
      fontSize: '0.875rem', // 14px
      fontWeight: 400,
      lineHeight: 1.5,
      letterSpacing: '0em',
      fontFamily: '"Fira Code", monospace',
    },
    codeSmall: {
      fontSize: '0.75rem', // 12px
      fontWeight: 400,
      lineHeight: 1.5,
      letterSpacing: '0em',
      fontFamily: '"Fira Code", monospace',
    },
  },
};

export type TypographyScale = keyof typeof typography.scales;
export type FontWeight = keyof typeof typography.fontWeight;
export type FontSize = keyof typeof typography.fontSize;
