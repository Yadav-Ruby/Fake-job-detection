import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Shield, Users, Award, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export default function LandingPage() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-red-500/10 blur-3xl"></div>
          <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-blue-500/10 blur-3xl"></div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-6 text-center"
        >
          <motion.div variants={itemVariants} className="inline-flex items-center space-x-2 rounded-full border border-slate-700/50 bg-slate-800/30 px-4 py-2">
            <AlertCircle className="h-4 w-4 text-red-400" />
            <span className="text-sm text-slate-300">Protecting 100K+ students from scams</span>
          </motion.div>

          <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-white via-red-400 to-white bg-clip-text text-transparent">
            Your Career Safety Guard
          </motion.h1>

          <motion.p variants={itemVariants} className="mx-auto max-w-2xl text-xl text-slate-400">
            AI-powered platform that identifies fake jobs, recruiter scams, and phishing attempts in seconds. Stay safe, stay smart.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/scam-checker">
              <Button variant="primary" size="lg">
                <Shield className="h-5 w-5" />
                Check for Scams
              </Button>
            </Link>
            <Button variant="outline" size="lg">
              Watch Demo <ArrowRight className="h-5 w-5" />
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* Trust Metrics */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: Users, label: 'Active Users', value: '100K+' },
            { icon: AlertCircle, label: 'Scams Detected', value: '50K+' },
            { icon: Award, label: 'Accuracy Rate', value: '99.2%' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group relative"
            >
              <Card className="p-6 text-center">
                <stat.icon className="h-8 w-8 mx-auto mb-4 text-red-400" />
                <div className="text-sm text-slate-400 mb-2">{stat.label}</div>
                <div className="text-3xl font-bold text-white">{stat.value}</div>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true }} className="space-y-12">
          <div className="text-center space-y-2">
            <h2 className="text-4xl md:text-5xl font-bold">Detect Every Type of Scam</h2>
            <p className="text-slate-400 text-lg">Comprehensive protection against common student career scams</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: 'Fake Job Listings', desc: 'Identify suspicious job posts with AI analysis' },
              { title: 'Recruiter Scams', desc: 'Verify recruiter legitimacy and credentials' },
              { title: 'Registration Fees', desc: 'Spot hidden fees before you apply' },
              { title: 'Phishing Attempts', desc: 'Detect malicious links and emails' },
              { title: 'WhatsApp Scams', desc: 'Recognize hiring via messaging apps' },
              { title: 'Telegram Threats', desc: 'Safe verification for job offers' },
            ].map((feature, i) => (
              <motion.div key={i} variants={itemVariants}>
                <Card className="p-6 h-full">
                  <CheckCircle2 className="h-6 w-6 text-green-400 mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-slate-400 text-sm">{feature.desc}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* How It Works */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="space-y-12"
        >
          <div className="text-center space-y-2">
            <h2 className="text-4xl md:text-5xl font-bold">How It Works</h2>
            <p className="text-slate-400 text-lg">Simple, fast, and secure</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: 1, title: 'Submit Info', desc: 'Paste job link, description, or screenshot' },
              { step: 2, title: 'AI Analysis', desc: 'Our model analyzes for fraud signals' },
              { step: 3, title: 'Get Results', desc: 'Instant risk score and recommendations' },
            ].map((item, i) => (
              <motion.div key={i} variants={itemVariants} className="relative">
                <div className="flex flex-col items-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-600 text-white font-bold text-xl mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2 text-center">{item.title}</h3>
                  <p className="text-slate-400 text-center text-sm">{item.desc}</p>
                </div>
                {i < 2 && (
                  <div className="hidden md:block absolute top-8 -right-4 text-slate-700">
                    <ArrowRight className="h-6 w-6" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Testimonials */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="space-y-12"
        >
          <div className="text-center space-y-2">
            <h2 className="text-4xl md:text-5xl font-bold">Trusted by Students</h2>
            <p className="text-slate-400 text-lg">Read what real users say</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: 'Sarah M.', role: 'Engineering Student', text: 'Saved me from a fake Google internship. Highly recommend!' },
              { name: 'Raj P.', role: 'Business Student', text: 'The recruiter verification tool is incredibly accurate. Great work!' },
              { name: 'Emma L.', role: 'CS Major', text: 'Finally a tool that protects students like us. Keep it up!' },
            ].map((testimonial, i) => (
              <motion.div key={i} variants={itemVariants}>
                <Card className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, j) => (
                      <div key={j} className="text-yellow-400">★</div>
                    ))}
                  </div>
                  <p className="text-slate-300 mb-4 italic">"{testimonial.text}"</p>
                  <div>
                    <p className="font-semibold text-white">{testimonial.name}</p>
                    <p className="text-slate-400 text-sm">{testimonial.role}</p>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="space-y-12"
        >
          <div className="text-center space-y-2">
            <h2 className="text-4xl md:text-5xl font-bold">Frequently Asked</h2>
            <p className="text-slate-400 text-lg">Get answers to common questions</p>
          </div>

          <div className="space-y-4">
            {[
              { q: 'Is ScamGuard AI free?', a: 'Yes, basic features are completely free. Premium features coming soon.' },
              { q: 'How accurate is the detection?', a: 'Our AI model has 99.2% accuracy based on industry data and patterns.' },
              { q: 'Is my data safe?', a: 'Absolutely. We never store personal data and use enterprise-grade encryption.' },
              { q: 'Can I report scams?', a: 'Yes! You can submit scams to help improve our detection model.' },
            ].map((item, i) => (
              <motion.div key={i} variants={itemVariants}>
                <Card className="p-6">
                  <h3 className="font-semibold text-white mb-2">{item.q}</h3>
                  <p className="text-slate-400">{item.a}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative rounded-3xl overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-blue-500/20 blur-2xl -z-10"></div>
          <Card className="p-12 text-center border border-red-500/30">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Ready to Stay Safe?</h2>
            <p className="text-slate-400 text-lg mb-8 max-w-2xl mx-auto">
              Join thousands of students already using ScamGuard AI to protect their career.
            </p>
            <Link to="/scam-checker">
              <Button variant="primary" size="lg">
                <Shield className="h-5 w-5" />
                Start Checking Now
              </Button>
            </Link>
          </Card>
        </motion.div>
      </section>
    </div>
  );
}
