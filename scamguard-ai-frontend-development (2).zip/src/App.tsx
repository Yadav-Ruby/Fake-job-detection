
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import PremiumLanding from './pages/PremiumLanding';
import FlagshipScamChecker from './pages/FlagshipScamChecker';
import ModernCareerAssistant from './pages/ModernCareerAssistant';
import RecruiterVerification from './pages/RecruiterVerification';
import LearningCenter from './pages/LearningCenter';
import ReportScam from './pages/ReportScam';
import AdminDashboard from './pages/AdminDashboard';
import DesignSystemShowcase from './pages/DesignSystemShowcase';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100">
        <Navbar />
        <Routes>
          <Route path="/" element={<PremiumLanding />} />
          <Route path="/scam-checker" element={<FlagshipScamChecker />} />
          <Route path="/recruiter-verification" element={<RecruiterVerification />} />
          <Route path="/career-assistant" element={<ModernCareerAssistant />} />
          <Route path="/learning-center" element={<LearningCenter />} />
          <Route path="/report-scam" element={<ReportScam />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/design-system" element={<DesignSystemShowcase />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}
