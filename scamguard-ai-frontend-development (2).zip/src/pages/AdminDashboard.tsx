import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, AlertTriangle, Users, Activity, Eye } from 'lucide-react';
import Card from '../components/ui/Card';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export default function AdminDashboard() {
  return (
    <div className="min-h-screen py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="text-5xl md:text-6xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-slate-400 text-lg">Real-time fraud monitoring and platform analytics</p>
        </motion.div>

        {/* Statistics Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
        >
          {[
            { icon: Users, label: 'Total Users', value: '124.5K', change: '+12.5%' },
            { icon: Activity, label: 'Scams Detected', value: '52.3K', change: '+8.2%' },
            { icon: TrendingUp, label: 'Reports Today', value: '342', change: '+15.3%' },
            { icon: AlertTriangle, label: 'Pending Review', value: '47', change: '-3.1%' },
          ].map((stat, i) => (
            <motion.div key={i} variants={itemVariants}>
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <stat.icon className="h-8 w-8 text-red-400" />
                  <span className={`text-sm font-semibold ${stat.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                    {stat.change}
                  </span>
                </div>
                <p className="text-slate-400 text-sm mb-1">{stat.label}</p>
                <p className="text-3xl font-bold text-white">{stat.value}</p>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
          {/* Fraud Trends Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-white">Fraud Trends (Last 7 Days)</h3>
                <BarChart3 className="h-5 w-5 text-slate-400" />
              </div>

              <div className="space-y-4">
                {[
                  { label: 'Fake Jobs', value: 45, max: 100 },
                  { label: 'Recruiter Scams', value: 28, max: 100 },
                  { label: 'Registration Fees', value: 32, max: 100 },
                  { label: 'Phishing', value: 18, max: 100 },
                  { label: 'Messaging App Scams', value: 22, max: 100 },
                ].map((trend, i) => (
                  <div key={i}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium text-slate-300">{trend.label}</span>
                      <span className="text-sm font-bold text-white">{trend.value}%</span>
                    </div>
                    <div className="relative h-2 bg-slate-700/50 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${trend.value}%` }}
                        transition={{ duration: 1.5, delay: i * 0.1 }}
                        className="h-full bg-gradient-to-r from-red-500 to-red-600"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Top Scammers */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Most Active Scammers</h3>
              <div className="space-y-3">
                {[
                  { name: 'Domain Spoof Inc.', reports: 156 },
                  { name: 'Fake Jobs Ltd', reports: 134 },
                  { name: 'Phishing Pro', reports: 98 },
                ].map((scammer, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + i * 0.1 }}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-red-500/20 flex items-center justify-center text-xs font-bold text-red-400">
                        {i + 1}
                      </div>
                      <span className="text-sm text-slate-300">{scammer.name}</span>
                    </div>
                    <span className="text-sm font-bold text-red-400">{scammer.reports}</span>
                  </motion.div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
          {/* Keyword Analysis */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Suspicious Keywords</h3>
              <div className="flex flex-wrap gap-2">
                {['guaranteed', 'wire transfer', 'urgent', 'no experience', 'quick money', 'bitcoin', 'confidential', 'work from home', 'bonus', 'limited time'].map((keyword, i) => (
                  <motion.span
                    key={i}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 + i * 0.05 }}
                    className="px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/30 text-xs font-medium"
                  >
                    {keyword}
                  </motion.span>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Recent Reports */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Recent Reports</h3>
              <div className="space-y-3">
                {[
                  { type: 'Fake Job', reporter: 'Sarah M.', time: '5m ago' },
                  { type: 'Recruiter Scam', reporter: 'Raj P.', time: '12m ago' },
                  { type: 'Phishing', reporter: 'Emma L.', time: '18m ago' },
                ].map((report, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + i * 0.1 }}
                    className="flex items-center justify-between"
                  >
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">{report.type}</p>
                      <p className="text-xs text-slate-400">by {report.reporter}</p>
                    </div>
                    <span className="text-xs text-slate-400">{report.time}</span>
                  </motion.div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Reports Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-6 overflow-x-auto">
            <h3 className="text-lg font-semibold text-white mb-4">Fraud Trends Analysis</h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700/50">
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Scam Type</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">Today</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">This Week</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">This Month</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">Trend</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { type: 'Fake Job Listings', today: 42, week: 235, month: 845, trend: '↑' },
                  { type: 'Recruiter Scams', today: 28, week: 156, month: 512, trend: '↑' },
                  { type: 'Registration Fees', today: 32, week: 178, month: 623, trend: '→' },
                  { type: 'Phishing Attempts', today: 18, week: 95, month: 287, trend: '↓' },
                  { type: 'Messaging App Scams', today: 22, week: 118, month: 401, trend: '↑' },
                ].map((row, i) => (
                  <motion.tr
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 + i * 0.05 }}
                    className="border-b border-slate-700/30 hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="py-4 px-4 text-slate-300">{row.type}</td>
                    <td className="py-4 px-4 text-center text-white font-semibold">{row.today}</td>
                    <td className="py-4 px-4 text-center text-white font-semibold">{row.week}</td>
                    <td className="py-4 px-4 text-center text-white font-semibold">{row.month}</td>
                    <td className={`py-4 px-4 text-center font-bold ${row.trend === '↑' ? 'text-red-400' : row.trend === '↓' ? 'text-green-400' : 'text-yellow-400'}`}>
                      {row.trend}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </Card>
        </motion.div>

        {/* System Health */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-12"
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white">System Health</h3>
              <Eye className="h-5 w-5 text-green-400" />
            </div>

            <div className="space-y-4">
              {[
                { name: 'API Response Time', status: '120ms', health: 'Good' },
                { name: 'Detection Accuracy', status: '99.2%', health: 'Excellent' },
                { name: 'Database Performance', status: 'Normal', health: 'Good' },
                { name: 'Model Training', status: 'In Progress', health: 'Running' },
              ].map((system, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + i * 0.1 }}
                  className="flex items-center justify-between"
                >
                  <span className="text-slate-300">{system.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-slate-400">{system.status}</span>
                    <div className="h-2 w-2 rounded-full bg-green-400"></div>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
