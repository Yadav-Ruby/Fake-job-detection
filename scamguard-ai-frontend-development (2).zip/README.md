# ScamGuard AI - Student Career Safety Platform

A modern, premium SaaS frontend application built with React, TypeScript, Tailwind CSS, and Framer Motion. ScamGuard AI helps students identify and avoid career-related scams.

## 🎨 Design Philosophy

- **Premium SaaS**: Linear, Stripe, Notion-inspired design language
- **Dark Mode First**: Beautiful dark theme with soft shadows and glassmorphism
- **Student Friendly**: Intuitive, accessible, and engaging UI/UX
- **Trustworthy**: Professional and reliable appearance

## 🛡️ Features

### 1. Landing Page
- Hero section with trust metrics
- Scam trends dashboard
- 6 feature highlights
- How it works section
- Student testimonials
- FAQ section
- Email capture CTA

### 2. Scam Checker
- Multi-input support:
  - URL analysis
  - Job description text analysis
  - Screenshot verification
- Real-time AI analysis
- Risk score visualization with animated ring progress
- Fraud signal detection
- Suspicious keyword highlighting
- Action buttons (copy, download, report)

### 3. Recruiter Verification
- Email-based recruiter lookup
- Trust score system (0-100)
- Domain age verification
- SSL certificate status
- Fraud report count
- Three verification states:
  - ✓ Verified (Green)
  - ⚠️ Suspicious (Yellow)
  - ✗ Blacklisted (Red)
- Detailed recruiter information cards

### 4. Career Safety Assistant
- AI-powered chatbot interface
- Suggested questions for quick access
- Typing animation for assistant responses
- Message history with timestamps
- Responsive design for mobile and desktop
- Real-time conversation state management

### 5. Learning Center
- 4 learning modes:
  - Scam categories with lessons
  - Safety articles (6+ articles)
  - Interactive quizzes (4 difficulty levels)
  - Achievement system with progress tracking
- Progress tracker showing:
  - Scam checks completed
  - Articles read
  - Quizzes passed
- Gamification elements

### 6. Report Scam
- Single-page form with multiple steps
- Scam type selection (6 categories)
- Detailed description input
- Optional email and website fields
- Screenshot upload capability
- Success confirmation state
- Privacy and data handling information

### 7. Admin Dashboard
- Real-time statistics cards
- Fraud trends visualization
- Top scammers leaderboard
- Recent reports feed
- Suspicious keywords cloud
- Comprehensive analytics table
- System health monitoring

## 🎯 Technical Stack

- **React 19**: Latest React features
- **TypeScript**: Full type safety
- **Tailwind CSS 4**: Utility-first CSS framework
- **Framer Motion**: Beautiful animations and transitions
- **Lucide React**: Premium icon library
- **React Router**: Client-side routing
- **Vite**: Lightning-fast build tool

## 🎨 Color System

```
Primary:     #EF4444 (Red)
Warning:     #F59E0B (Amber)
Success:     #10B981 (Green)
Info:        #3B82F6 (Blue)
Background:  #0F172A (Dark Blue)
Card:        #111827 (Dark Gray)
Border:      #1E293B (Slate)
Text:        #F8FAFC (Off White)
Muted:       #94A3B8 (Gray)
```

## 🏗️ Component Architecture

### Shared Components
- `Navbar`: Sticky navigation with mobile menu
- `Footer`: Comprehensive footer with links
- `ui/Button`: Versatile button component (4 variants, 3 sizes)
- `ui/Card`: Glassmorphic card component with animations

### Page Components
- Each page is fully self-contained with animations
- Mobile-first responsive design
- Smooth transitions between pages

## 🎬 Animation Features

- Page entry animations
- Card hover effects
- Progress bar animations
- Staggered list animations
- Smooth transitions
- Loading states with spinners
- Success animations with confetti-like effects

## 📱 Responsive Design

- Mobile-first approach
- Breakpoints:
  - sm: 640px
  - md: 768px
  - lg: 1024px
  - xl: 1280px
- Optimized touch interactions
- Readable on all screen sizes

## ♿ Accessibility

- Semantic HTML
- ARIA labels
- Keyboard navigation support
- Focus management
- Color contrast compliance
- Screen reader friendly

## 🚀 Performance

- Optimized animations
- Lazy loading components
- Efficient state management
- CSS purging
- Minified production build
- Single-file deployment ready

## 📦 Installation

```bash
npm install
npm run dev      # Development server
npm run build    # Production build
npm run preview  # Preview built app
```

## 🎯 Key Pages Overview

### Landing Page
The entry point featuring:
- Attention-grabbing hero with gradient text
- Trust metrics (100K+ users, 50K+ scams detected)
- Clear CTA buttons
- Feature grid with icons
- Social proof through testimonials
- Educational FAQ section

### Scam Checker
Advanced analysis tool with:
- Tab-based input (URL, Text, Screenshot)
- Real-time risk calculation
- Visual risk score (0-100% animated ring)
- Color-coded risk levels
- Detailed fraud signal breakdown
- Keyword analysis
- Action buttons for sharing results

### Recruiter Verification
Comprehensive verification system:
- Email-based search
- Trust score visualization
- Domain age analysis
- SSL/TLS certificate status
- Fraud report count
- Status badges (Verified/Suspicious/Blacklisted)
- Detailed metrics grid

### Career Assistant
Intelligent chatbot interface:
- Suggested questions for quick starts
- Multi-turn conversations
- Typing animation for AI responses
- Persistent message history
- Mobile-optimized input
- Helpful safety tips

### Learning Center
Educational platform with:
- Organized scam categories
- Full article library
- Multiple quiz difficulty levels
- Achievement system with progress
- Gamification elements
- Progress tracking dashboard

### Report Scam
Community-driven reporting:
- 6 scam type categories
- Detailed description fields
- File upload for evidence
- Optional contact information
- Success confirmation
- Privacy assurance

### Admin Dashboard
Analytics and monitoring:
- Real-time KPI cards
- 7-day fraud trend analysis
- Top scammers leaderboard
- Recent report feed
- Keyword cloud analysis
- Comprehensive data table
- System health indicators

## 🎨 Design Highlights

### Glassmorphism
- Semi-transparent backgrounds
- Backdrop blur effects
- Layered depth perception

### Gradients
- Linear gradients on buttons
- Radial gradients for backgrounds
- Text gradients for emphasis

### Shadows
- Soft, layered shadows
- Glow effects on interactive elements
- Depth through shadow hierarchy

### Typography
- Inter font family throughout
- Clear hierarchy with weights
- Readable line heights
- Proper text sizing

## 📊 Content Specifications

### Scam Types Covered
1. Fake Job Listings
2. Recruiter Scams
3. Registration Fee Scams
4. Phishing Attempts
5. WhatsApp Hiring Scams
6. Telegram Hiring Scams

### Features Highlighted
- Red flags identification
- Company verification
- Email authentication
- Suspicious keyword detection
- Professional communication analysis
- Payment safety verification

## 🔒 Privacy & Security Features

- No data persistence in frontend
- Client-side processing emphasis
- Privacy policy compliance
- User data protection messaging
- Secure form handling
- HTTPS ready

## 🎓 Learning Resources

- 12+ lessons in Fake Jobs category
- 8+ lessons in Recruiter Scams
- 10+ lessons in Registration Fees
- 15+ lessons in Phishing
- 6 full articles
- 4 quiz difficulty levels
- Achievement tracking system

## 📈 Analytics & Monitoring

Admin dashboard provides:
- User engagement metrics
- Scam detection statistics
- Real-time fraud trends
- Top scammer tracking
- Keyword analysis
- System health monitoring

## 🌟 User Experience Features

- Smooth page transitions
- Loading states
- Success confirmations
- Error states (ready to implement)
- Empty states
- Helpful CTAs
- Progressive disclosure

## 🚀 Future Enhancements

- Real API integration
- Backend authentication
- User accounts and profiles
- Email notifications
- SMS alerts
- Browser extensions
- Mobile app
- Advanced ML models
- Community forums
- Verified company badges

## 📄 License

Built with ❤️ for student safety

---

**ScamGuard AI - Protecting Students, One Check at a Time**
