/**
 * ScamGuard AI - Color System
 * Comprehensive color palette for the design system
 */

export const colors = {
  // Primary Colors
  primary: {
    50: '#FEF2F2',
    100: '#FEE2E2',
    200: '#FECACA',
    300: '#FCA5A5',
    400: '#F87171',
    500: '#EF4444', // Main primary
    600: '#DC2626',
    700: '#B91C1C',
    800: '#991B1B',
    900: '#7F1D1D',
  },

  // Secondary Colors
  secondary: {
    50: '#EFF6FF',
    100: '#DBEAFE',
    200: '#BFDBFE',
    300: '#93C5FD',
    400: '#60A5FA',
    500: '#3B82F6', // Main secondary
    600: '#2563EB',
    700: '#1D4ED8',
    800: '#1E40AF',
    900: '#1E3A8A',
  },

  // Success Colors
  success: {
    50: '#F0FDF4',
    100: '#DCFCE7',
    200: '#BBF7D0',
    300: '#86EFAC',
    400: '#4ADE80',
    500: '#10B981', // Main success
    600: '#059669',
    700: '#047857',
    800: '#065F46',
    900: '#064E3B',
  },

  // Warning Colors
  warning: {
    50: '#FFFBEB',
    100: '#FEF3C7',
    200: '#FDE68A',
    300: '#FCD34D',
    400: '#FBBF24',
    500: '#F59E0B', // Main warning
    600: '#D97706',
    700: '#B45309',
    800: '#92400E',
    900: '#78350F',
  },

  // Danger Colors
  danger: {
    50: '#FEF2F2',
    100: '#FEE2E2',
    200: '#FECACA',
    300: '#FCA5A5',
    400: '#F87171',
    500: '#EF4444', // Same as primary
    600: '#DC2626',
    700: '#B91C1C',
    800: '#991B1B',
    900: '#7F1D1D',
  },

  // Info Colors
  info: {
    50: '#EFF6FF',
    100: '#DBEAFE',
    200: '#BFDBFE',
    300: '#93C5FD',
    400: '#60A5FA',
    500: '#3B82F6', // Same as secondary
    600: '#2563EB',
    700: '#1D4ED8',
    800: '#1E40AF',
    900: '#1E3A8A',
  },

  // Neutral Colors (Dark theme)
  neutral: {
    50: '#F8FAFC', // Off-white text
    100: '#F1F5F9',
    150: '#E2E8F0',
    200: '#CBD5E1',
    300: '#94A3B8', // Muted text
    400: '#64748B',
    500: '#475569',
    600: '#334155',
    700: '#1E293B', // Borders
    800: '#0F172A', // Card background
    900: '#020617', // Near black
  },

  // Background Colors (Dark theme)
  background: {
    primary: '#0F172A', // Main background
    secondary: '#111827', // Card backgrounds
    tertiary: '#1E293B', // Borders
    hover: '#1E293B',
    active: '#334155',
  },

  // Semantic Colors
  semantic: {
    safe: '#10B981',
    warning: '#F59E0B',
    danger: '#EF4444',
    info: '#3B82F6',
    verified: '#10B981',
    suspicious: '#F59E0B',
    blacklisted: '#EF4444',
  },

  // Transparent Variants
  transparent: {
    primary10: 'rgba(239, 68, 68, 0.1)',
    primary20: 'rgba(239, 68, 68, 0.2)',
    secondary10: 'rgba(59, 130, 246, 0.1)',
    secondary20: 'rgba(59, 130, 246, 0.2)',
    success10: 'rgba(16, 185, 129, 0.1)',
    success20: 'rgba(16, 185, 129, 0.2)',
    warning10: 'rgba(245, 158, 11, 0.1)',
    warning20: 'rgba(245, 158, 11, 0.2)',
  },

  // Gradients
  gradients: {
    primary: 'from-red-500 to-red-600',
    primaryHover: 'from-red-600 to-red-700',
    secondary: 'from-blue-500 to-blue-600',
    secondaryHover: 'from-blue-600 to-blue-700',
    success: 'from-green-500 to-green-600',
    warning: 'from-yellow-500 to-yellow-600',
    danger: 'from-red-500 to-red-600',
    primary2Secondary: 'from-red-500 to-blue-500',
    accent: 'from-purple-500 to-pink-500',
  },
};

export type ColorScheme = typeof colors;
export type ColorKey = keyof ColorScheme;
