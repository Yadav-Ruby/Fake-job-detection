/**
 * ScamGuard AI - Spacing System
 * Border radius, padding, and margin scales
 */

export const spacing = {
  // Border Radius
  borderRadius: {
    none: '0',
    xs: '0.25rem', // 4px
    sm: '0.375rem', // 6px
    base: '0.5rem', // 8px
    md: '0.75rem', // 12px
    lg: '1rem', // 16px
    xl: '1.5rem', // 24px
    '2xl': '2rem', // 32px
    '3xl': '2.5rem', // 40px
    '4xl': '3rem', // 48px
    full: '9999px', // Fully rounded
  },

  // Component-specific radius
  radius: {
    button: '0.75rem', // 12px
    input: '0.75rem', // 12px
    card: '1rem', // 16px
    cardLarge: '1.5rem', // 24px
    modal: '1.5rem', // 24px
    badge: '9999px', // Fully rounded
    chip: '9999px', // Fully rounded
    dropdown: '0.75rem', // 12px
    toast: '0.75rem', // 12px
    tooltip: '0.5rem', // 8px
    avatar: '9999px', // Fully rounded
  },

  // Padding Scale
  padding: {
    0: '0',
    1: '0.25rem', // 4px
    2: '0.5rem', // 8px
    3: '0.75rem', // 12px
    4: '1rem', // 16px
    5: '1.25rem', // 20px
    6: '1.5rem', // 24px
    7: '1.75rem', // 28px
    8: '2rem', // 32px
    9: '2.25rem', // 36px
    10: '2.5rem', // 40px
    12: '3rem', // 48px
    14: '3.5rem', // 56px
    16: '4rem', // 64px
    20: '5rem', // 80px
    24: '6rem', // 96px
  },

  // Component Padding
  componentPadding: {
    button: {
      sm: '0.5rem 0.75rem', // py-2 px-3
      md: '0.625rem 1rem', // py-2.5 px-4
      lg: '0.75rem 1.5rem', // py-3 px-6
    },
    input: {
      sm: '0.375rem 0.75rem', // py-1.5 px-3
      md: '0.5rem 1rem', // py-2 px-4
      lg: '0.75rem 1.25rem', // py-3 px-5
    },
    card: {
      sm: '1rem', // p-4
      md: '1.5rem', // p-6
      lg: '2rem', // p-8
      xl: '2.5rem', // p-10
    },
    badge: '0.375rem 0.75rem', // py-1.5 px-3
    chip: '0.5rem 1rem', // py-2 px-4
  },

  // Gap Scale (for flex/grid)
  gap: {
    0: '0',
    1: '0.25rem', // 4px
    2: '0.5rem', // 8px
    3: '0.75rem', // 12px
    4: '1rem', // 16px
    6: '1.5rem', // 24px
    8: '2rem', // 32px
    10: '2.5rem', // 40px
    12: '3rem', // 48px
    16: '4rem', // 64px
  },

  // Margin Scale
  margin: {
    0: '0',
    1: '0.25rem', // 4px
    2: '0.5rem', // 8px
    3: '0.75rem', // 12px
    4: '1rem', // 16px
    6: '1.5rem', // 24px
    8: '2rem', // 32px
    10: '2.5rem', // 40px
    12: '3rem', // 48px
  },

  // Section Spacing
  section: {
    xs: '1rem', // 16px
    sm: '1.5rem', // 24px
    md: '2rem', // 32px
    lg: '3rem', // 48px
    xl: '4rem', // 64px
    '2xl': '5rem', // 80px
  },
};

export type BorderRadius = keyof typeof spacing.borderRadius;
export type Padding = keyof typeof spacing.padding;
export type Gap = keyof typeof spacing.gap;
