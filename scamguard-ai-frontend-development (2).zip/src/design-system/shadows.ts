/**
 * ScamGuard AI - Shadow System
 * Elevation levels and shadow effects
 */

export const shadows = {
  // Elevation Levels
  none: 'none',

  // Subtle shadows
  sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
  base: '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',

  // Standard shadows
  md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
  lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
  xl: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
  '2xl': '0 25px 50px -12px rgb(0 0 0 / 0.25)',

  // Large shadows
  '3xl': '0 35px 60px -15px rgb(0 0 0 / 0.3)',
  '4xl': '0 40px 80px -20px rgb(0 0 0 / 0.35)',

  // Specialty shadows for dark theme
  dark: {
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.2)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.3), 0 2px 4px -2px rgb(0 0 0 / 0.2)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.4), 0 4px 6px -4px rgb(0 0 0 / 0.3)',
    xl: '0 20px 25px -5px rgb(0 0 0 / 0.4), 0 8px 10px -6px rgb(0 0 0 / 0.3)',
    '2xl': '0 25px 50px -12px rgb(0 0 0 / 0.5)',
  },

  // Glow effects (for colored elements)
  glowRed: '0 0 20px rgb(239, 68, 68 / 0.3)',
  glowBlue: '0 0 20px rgb(59, 130, 246 / 0.3)',
  glowGreen: '0 0 20px rgb(16, 185, 129 / 0.3)',
  glowYellow: '0 0 20px rgb(245, 158, 11 / 0.3)',
  glowPurple: '0 0 20px rgb(168, 85, 247 / 0.3)',

  // Inset shadows (for depth)
  insetSm: 'inset 0 1px 2px 0 rgb(0 0 0 / 0.05)',
  insetMd: 'inset 0 2px 4px 0 rgb(0 0 0 / 0.1)',

  // Hover states
  hover: {
    sm: '0 4px 6px -1px rgb(0 0 0 / 0.2)',
    md: '0 10px 15px -3px rgb(0 0 0 / 0.25)',
    lg: '0 20px 25px -5px rgb(0 0 0 / 0.3)',
  },

  // Focus states
  focus: {
    ring: '0 0 0 3px rgb(239, 68, 68 / 0.1)',
    ringSmall: '0 0 0 2px rgb(239, 68, 68 / 0.1)',
  },

  // Composite shadows (shadow + glow)
  elevated: {
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.1), 0 0 10px rgb(239, 68, 68 / 0.1)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.15), 0 0 15px rgb(239, 68, 68 / 0.15)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.2), 0 0 20px rgb(239, 68, 68 / 0.2)',
  },

  // Soft shadows for cards
  card: '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',
  cardHover: '0 10px 15px -3px rgb(0 0 0 / 0.15), 0 4px 6px -4px rgb(0 0 0 / 0.1)',

  // Modal shadows
  modal: '0 25px 50px -12px rgb(0 0 0 / 0.5)',

  // Backdrop shadows
  backdrop: 'inset 0 0 0 9999px rgb(0 0 0 / 0.5)',
};

export type ShadowKey = keyof typeof shadows;
