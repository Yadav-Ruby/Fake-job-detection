import { InputHTMLAttributes, ReactNode } from 'react';

type InputSize = 'sm' | 'md' | 'lg';
type InputType = 'text' | 'email' | 'password' | 'number' | 'url' | 'search';

interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'type'> {
  size?: InputSize;
  type?: InputType;
  label?: string;
  error?: string;
  success?: string;
  hint?: string;
  icon?: ReactNode;
  iconPosition?: 'left' | 'right';
  disabled?: boolean;
  fullWidth?: boolean;
}

const sizeStyles: Record<InputSize, string> = {
  sm: 'px-3 py-1.5 text-sm',
  md: 'px-4 py-2 text-base',
  lg: 'px-5 py-3 text-lg',
};

export default function Input({
  size = 'md',
  type = 'text',
  label,
  error,
  success,
  hint,
  icon,
  iconPosition = 'left',
  disabled = false,
  fullWidth = false,
  className = '',
  ...props
}: InputProps) {
  const baseClasses =
    'bg-slate-900/50 border rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none transition-all duration-200 font-inter';
  const borderClasses = error
    ? 'border-red-500/50 focus:border-red-500 focus:ring-1 focus:ring-red-500/20'
    : success
      ? 'border-green-500/50 focus:border-green-500 focus:ring-1 focus:ring-green-500/20'
      : 'border-slate-700/50 focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20';
  const disabledClasses = disabled ? 'opacity-50 cursor-not-allowed bg-slate-900/30' : '';
  const widthClasses = fullWidth ? 'w-full' : '';
  const iconPaddingLeft = icon && iconPosition === 'left' ? 'pl-10' : '';
  const iconPaddingRight = icon && iconPosition === 'right' ? 'pr-10' : '';

  return (
    <div className={widthClasses}>
      {label && (
        <label className="block text-sm font-semibold text-slate-200 mb-2">
          {label}
          {props.required && <span className="text-red-400 ml-1">*</span>}
        </label>
      )}

      <div className="relative">
        {icon && (
          <div
            className={`absolute top-1/2 -translate-y-1/2 text-slate-400 ${iconPosition === 'left' ? 'left-3' : 'right-3'} pointer-events-none flex items-center`}
          >
            {icon}
          </div>
        )}

        <input
          type={type}
          disabled={disabled}
          className={`${baseClasses} ${sizeStyles[size]} ${borderClasses} ${disabledClasses} ${iconPaddingLeft} ${iconPaddingRight} ${className}`}
          {...props}
        />
      </div>

      {error && <p className="text-red-400 text-sm mt-1.5">{error}</p>}
      {success && <p className="text-green-400 text-sm mt-1.5">{success}</p>}
      {hint && !error && !success && <p className="text-slate-400 text-sm mt-1.5">{hint}</p>}
    </div>
  );
}
