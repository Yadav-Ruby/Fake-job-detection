import { Link } from 'react-router-dom';
import { Shield, Share2, Globe, Code, Send } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-slate-800 bg-slate-950/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="rounded-lg bg-gradient-to-br from-red-500 to-red-600 p-2">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-white">ScamGuard AI</span>
            </div>
            <p className="text-slate-400 text-sm">
              Protecting students from career scams with AI-powered verification.
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="font-semibold text-white mb-4">Product</h3>
            <ul className="space-y-2 text-slate-400 text-sm">
              <li>
                <Link to="/scam-checker" className="hover:text-white transition-colors">
                  Scam Checker
                </Link>
              </li>
              <li>
                <Link to="/recruiter-verification" className="hover:text-white transition-colors">
                  Recruiter Verify
                </Link>
              </li>
              <li>
                <Link to="/career-assistant" className="hover:text-white transition-colors">
                  Career Assistant
                </Link>
              </li>
              <li>
                <Link to="/learning-center" className="hover:text-white transition-colors">
                  Learning Center
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2 text-slate-400 text-sm">
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="font-semibold text-white mb-4">Follow</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Share2 className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Globe className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Code className="h-5 w-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Send className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-slate-400 text-sm">
            © 2024 ScamGuard AI. All rights reserved.
          </p>
          <p className="text-slate-500 text-sm mt-4 md:mt-0">
            Made with ❤️ for student safety
          </p>
        </div>
      </div>
    </footer>
  );
}
