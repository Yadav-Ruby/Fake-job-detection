import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, Shield, Lock, Zap, Eye } from 'lucide-react';
import Button from '../design-system/components/Button';
import Input from '../design-system/components/Input';
import Card from '../design-system/components/Card';
import Badge from '../design-system/components/Badge';
import RiskChip from '../design-system/components/RiskChip';
import ScoreRing from '../design-system/components/ScoreRing';
import { colors } from '../design-system/colors';
import { shadows } from '../design-system/shadows';
import { spacing } from '../design-system/spacing';

export default function DesignSystemShowcase() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-red-400 to-blue-400 bg-clip-text text-transparent mb-4">
            Design System
          </h1>
          <p className="text-slate-400 text-lg">ScamGuard AI Complete Component Library</p>
        </motion.div>

        {/* Color System */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <Zap className="text-yellow-400" />
            Color System
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {/* Primary Colors */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Primary Colors</h3>
              <div className="space-y-2">
                {[50, 100, 300, 500, 600, 700, 900].map((shade) => (
                  <div key={shade} className="flex items-center gap-2">
                    <div
                      className="w-12 h-12 rounded-lg"
                      style={{
                        backgroundColor: colors.primary[shade as keyof typeof colors.primary],
                      }}
                    />
                    <div>
                      <p className="text-sm font-medium text-slate-200">Red-{shade}</p>
                      <p className="text-xs text-slate-400">{colors.primary[shade as keyof typeof colors.primary]}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Secondary Colors */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Secondary Colors</h3>
              <div className="space-y-2">
                {[50, 100, 300, 500, 600, 700, 900].map((shade) => (
                  <div key={shade} className="flex items-center gap-2">
                    <div
                      className="w-12 h-12 rounded-lg"
                      style={{
                        backgroundColor: colors.secondary[shade as keyof typeof colors.secondary],
                      }}
                    />
                    <div>
                      <p className="text-sm font-medium text-slate-200">Blue-{shade}</p>
                      <p className="text-xs text-slate-400">{colors.secondary[shade as keyof typeof colors.secondary]}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Semantic Colors */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Semantic Colors</h3>
              <div className="space-y-3">
                {Object.entries(colors.semantic).map(([name, value]) => (
                  <div key={name} className="flex items-center gap-2">
                    <div className="w-12 h-12 rounded-lg" style={{ backgroundColor: value }} />
                    <div>
                      <p className="text-sm font-medium text-slate-200 capitalize">{name}</p>
                      <p className="text-xs text-slate-400">{value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </section>

        {/* Buttons */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <AlertCircle className="text-red-400" />
            Buttons
          </h2>

          <Card className="mb-6">
            <h3 className="text-lg font-semibold text-white mb-6">Button Variants</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Button variant="primary">Primary Button</Button>
              <Button variant="secondary">Secondary Button</Button>
              <Button variant="outline">Outline Button</Button>
              <Button variant="ghost">Ghost Button</Button>
              <Button variant="danger">Danger Button</Button>
              <Button variant="success">Success Button</Button>
            </div>
          </Card>

          <Card>
            <h3 className="text-lg font-semibold text-white mb-6">Button Sizes</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-4 flex-wrap">
                <Button size="sm">Small</Button>
                <Button size="md">Medium</Button>
                <Button size="lg">Large</Button>
                <Button size="xl">Extra Large</Button>
              </div>
            </div>
          </Card>

          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-6">Button States</h3>
            <div className="flex flex-wrap items-center gap-4">
              <Button icon={<Shield className="h-4 w-4" />}>With Icon</Button>
              <Button disabled>Disabled</Button>
              <Button loading>Loading</Button>
              <Button fullWidth={false} variant="secondary">
                Secondary
              </Button>
            </div>
          </Card>
        </section>

        {/* Inputs */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <Lock className="text-blue-400" />
            Inputs
          </h2>

          <Card>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input label="Text Input" placeholder="Enter text..." />
              <Input label="Email Input" type="email" placeholder="Enter email..." />
              <Input
                label="Input with Icon"
                icon={<Shield className="h-4 w-4" />}
                placeholder="Protected..."
              />
              <Input label="Input with Error" error="This field is required" />
              <Input label="Input with Success" success="Email verified!" />
              <Input label="Disabled Input" disabled value="Cannot edit" />
            </div>
          </Card>
        </section>

        {/* Cards */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <Eye className="text-green-400" />
            Cards
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card variant="default">
              <p className="text-slate-300">Default Card</p>
            </Card>
            <Card variant="elevated">
              <p className="text-slate-300">Elevated Card</p>
            </Card>
            <Card variant="outlined">
              <p className="text-slate-300">Outlined Card</p>
            </Card>
            <Card variant="flat">
              <p className="text-slate-300">Flat Card</p>
            </Card>
            <Card title="Card with Title" subtitle="And subtitle">
              <p className="text-slate-300">This card has a title and subtitle</p>
            </Card>
            <Card
              title="Interactive Card"
              icon={<CheckCircle2 className="h-5 w-5 text-green-400" />}
              interactive
            >
              <p className="text-slate-300">Click me!</p>
            </Card>
          </div>
        </section>

        {/* Badges */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <CheckCircle2 className="text-green-400" />
            Badges
          </h2>

          <Card>
            <h3 className="text-lg font-semibold text-white mb-6">Badge Variants</h3>
            <div className="flex flex-wrap gap-4">
              <Badge variant="default">Default</Badge>
              <Badge variant="primary">Primary</Badge>
              <Badge variant="secondary">Secondary</Badge>
              <Badge variant="success">Success</Badge>
              <Badge variant="warning">Warning</Badge>
              <Badge variant="danger">Danger</Badge>
              <Badge variant="info">Info</Badge>
            </div>
          </Card>

          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-6">Badge Sizes & Features</h3>
            <div className="space-y-4">
              <div className="flex flex-wrap gap-3">
                <Badge size="sm">Small</Badge>
                <Badge size="md">Medium</Badge>
                <Badge size="lg">Large</Badge>
              </div>
              <div className="flex flex-wrap gap-3">
                <Badge dotted variant="success">
                  With Dot
                </Badge>
                <Badge icon={<CheckCircle2 className="h-3 w-3" />}>With Icon</Badge>
                <Badge dismissible>Dismissible</Badge>
              </div>
            </div>
          </Card>
        </section>

        {/* Risk Chips */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <AlertCircle className="text-red-400" />
            Risk Chips
          </h2>

          <Card>
            <h3 className="text-lg font-semibold text-white mb-6">Risk Levels</h3>
            <div className="flex flex-wrap gap-4">
              <RiskChip level="safe" />
              <RiskChip level="low" />
              <RiskChip level="medium" />
              <RiskChip level="high" />
              <RiskChip level="critical" />
            </div>
          </Card>

          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-6">Verification Status</h3>
            <div className="flex flex-wrap gap-4">
              <RiskChip level="verified" />
              <RiskChip level="suspicious" />
              <RiskChip level="blacklisted" />
            </div>
          </Card>

          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-6">Chip Sizes</h3>
            <div className="flex flex-wrap gap-4">
              <RiskChip level="safe" size="sm" />
              <RiskChip level="warning" size="md" />
              <RiskChip level="danger" size="lg" />
            </div>
          </Card>
        </section>

        {/* Score Rings */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <Zap className="text-yellow-400" />
            Score Rings
          </h2>

          <Card>
            <h3 className="text-lg font-semibold text-white mb-8">Safe (Green)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <ScoreRing score={5} level="safe" size="sm" label="Risk Score" />
              <ScoreRing score={15} level="safe" size="md" label="Safe Level" subLabel="No threats" />
              <ScoreRing score={25} level="safe" size="lg" label="Verified" subLabel="Company confirmed" />
              <ScoreRing score={35} level="safe" size="xl" label="Trust Score" />
            </div>
          </Card>

          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-8">Warning (Yellow)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <ScoreRing score={45} level="warning" size="sm" label="Suspicious" />
              <ScoreRing score={55} level="warning" size="md" label="Review Needed" subLabel="Some flags" />
              <ScoreRing score={65} level="warning" size="lg" label="Warning" subLabel="Check carefully" />
              <ScoreRing score={72} level="warning" size="xl" label="Caution" />
            </div>
          </Card>

          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-white mb-8">Danger (Red)</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <ScoreRing score={85} level="danger" size="sm" label="High Risk" />
              <ScoreRing score={88} level="danger" size="md" label="Likely Scam" subLabel="Avoid" />
              <ScoreRing score={95} level="danger" size="lg" label="Critical" subLabel="Danger zone" />
              <ScoreRing score={99} level="danger" size="xl" label="Blacklisted" />
            </div>
          </Card>
        </section>

        {/* Shadows */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
            <Eye className="text-purple-400" />
            Shadows & Elevation
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(shadows)
              .filter(([key]) => !key.startsWith('dark') && !key.startsWith('glow') && key !== 'none')
              .slice(0, 6)
              .map(([name, value]) => (
                <div
                  key={name}
                  className="h-32 bg-slate-800 rounded-lg border border-slate-700 flex items-center justify-center text-slate-400 font-medium"
                  style={{ boxShadow: value as string }}
                >
                  <p className="capitalize">{name}</p>
                </div>
              ))}
          </div>
        </section>

        {/* Border Radius */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8">Border Radius</h2>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Object.entries(spacing.borderRadius)
              .filter(([key]) => key !== 'none' && key !== 'full')
              .map(([name, value]) => (
                <div key={name} className="text-center">
                  <div
                    className="h-24 bg-gradient-to-br from-red-500 to-blue-500 mb-3"
                    style={{ borderRadius: value as string }}
                  />
                  <p className="text-xs text-slate-400 font-medium">{name}</p>
                  <p className="text-xs text-slate-500">{value}</p>
                </div>
              ))}
          </div>
        </section>

        {/* Full Component Example */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8">Component Examples</h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="Scam Analysis Result" icon={<AlertCircle className="h-5 w-5 text-red-400" />}>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Risk Score:</span>
                  <ScoreRing score={72} level="warning" size="sm" label="72%" />
                </div>
                <div>
                  <p className="text-slate-400 text-sm mb-2">Status:</p>
                  <RiskChip level="suspicious" />
                </div>
                <Button variant="primary" className="w-full">
                  View Details
                </Button>
              </div>
            </Card>

            <Card title="Recruiter Verification" icon={<CheckCircle2 className="h-5 w-5 text-green-400" />}>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Trust Score:</span>
                  <ScoreRing score={92} level="safe" size="sm" label="92%" />
                </div>
                <div>
                  <p className="text-slate-400 text-sm mb-2">Status:</p>
                  <RiskChip level="verified" />
                </div>
                <div className="flex gap-2">
                  <Badge variant="success">Verified</Badge>
                  <Badge dotted>Active</Badge>
                </div>
              </div>
            </Card>
          </div>
        </section>
      </div>
    </div>
  );
}
