import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Lightbulb, Loader } from 'lucide-react';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

const suggestedQuestions = [
  'How do I spot a fake job listing?',
  'What are common recruiter scam tactics?',
  'How to verify a company before applying?',
  'What should I do if I think I\'m being scammed?',
  'Is this job description suspicious?',
  'How to protect my personal information?',
];

export default function CareerSafetyAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hi! I\'m your Career Safety Assistant. I can help you identify potential scams, verify opportunities, and answer safety questions. What would you like to know?',
      sender: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: messageText,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate assistant response
    setTimeout(() => {
      const responses: { [key: string]: string } = {
        default:
          'That\'s a great question! Here are some key points to remember: 1) Always verify the company independently, 2) Be cautious of unsolicited job offers, 3) Never pay upfront fees, 4) Check for professional communication.',
      };

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: responses[messageText.toLowerCase()] || responses.default,
        sender: 'assistant',
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen py-12">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Career Safety Assistant</h1>
          <p className="text-slate-400 text-lg">AI-powered guidance for your job search safety</p>
        </motion.div>

        {/* Chat Container */}
        <Card className="flex flex-col h-[600px] lg:h-[700px]">
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message, i) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-2xl ${
                    message.sender === 'user'
                      ? 'bg-gradient-to-r from-red-500 to-red-600 text-white'
                      : 'bg-slate-800/50 border border-slate-700/50 text-slate-100'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.text}</p>
                  <span className="text-xs opacity-70 mt-2 block">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </motion.div>
            ))}

            {isLoading && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                <div className="bg-slate-800/50 border border-slate-700/50 px-4 py-3 rounded-2xl">
                  <div className="flex items-center gap-2">
                    <Loader className="h-4 w-4 animate-spin text-slate-400" />
                    <span className="text-sm text-slate-400">Thinking...</span>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Divider */}
          <div className="border-t border-slate-700/50"></div>

          {/* Input Area */}
          <div className="p-6 space-y-4">
            {/* Suggested Questions */}
            {messages.length === 1 && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
                <p className="text-xs text-slate-400 flex items-center gap-2 mb-3">
                  <Lightbulb className="h-4 w-4" />
                  Suggested questions:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {suggestedQuestions.slice(0, 4).map((question, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                      onClick={() => handleSendMessage(question)}
                      className="text-left px-3 py-2 rounded-lg bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:text-white hover:border-slate-600/50 transition-all text-xs"
                    >
                      {question}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Input Form */}
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Ask anything about job safety..."
                className="flex-1 bg-slate-900/50 border border-slate-700/50 rounded-lg px-4 py-2 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/20"
                disabled={isLoading}
              />
              <Button
                variant="primary"
                size="md"
                onClick={() => handleSendMessage()}
                disabled={!input.trim() || isLoading}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>

            {/* Info */}
            <p className="text-xs text-slate-500 text-center">
              Press Enter to send, or click suggested questions above
            </p>
          </div>
        </Card>

        {/* More Questions */}
        {messages.length > 1 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8"
          >
            <p className="text-sm text-slate-400 mb-4 flex items-center gap-2">
              <Lightbulb className="h-4 w-4" />
              More questions you can ask:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {suggestedQuestions.slice(4).map((question, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(question)}
                  className="text-left px-4 py-3 rounded-lg bg-slate-800/50 border border-slate-700/50 text-slate-300 hover:text-white hover:border-slate-600/50 transition-all text-sm"
                >
                  {question}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
