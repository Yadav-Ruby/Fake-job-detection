import { ReactNode } from 'react';
import { motion } from 'framer-motion';

type CardVariant = 'default' | 'elevated' | 'outlined' | 'flat' | 'interactive';
type CardPadding = 'sm' | 'md' | 'lg' | 'xl' | 'none';

interface CardProps {
  children: ReactNode;
  variant?: CardVariant;
  padding?: CardPadding;
  hover?: boolean;
  interactive?: boolean;
  onClick?: () => void;
  className?: string;
  title?: string;
  subtitle?: string;
  icon?: ReactNode;
  footer?: ReactNode;
}

const variantStyles: Record<CardVariant, string> = {
  default: 'bg-slate-800/40 border border-slate-700/50 backdrop-blur-xl',
  elevated: 'bg-slate-800/60 border border-slate-600/50 backdrop-blur-xl shadow-lg',
  outlined: 'bg-transparent border-2 border-slate-700/50 backdrop-blur-md',
  flat: 'bg-slate-800/50 border-none',
  interactive: 'bg-slate-800/40 border border-slate-700/50 backdrop-blur-xl cursor-pointer',
};

const paddingStyles: Record<CardPadding, string> = {
  sm: 'p-4',
  md: 'p-6',
  lg: 'p-8',
  xl: 'p-10',
  none: 'p-0',
};

export default function Card({
  children,
  variant = 'default',
  padding = 'md',
  hover = true,
  interactive = false,
  onClick,
  className = '',
  title,
  subtitle,
  icon,
  footer,
}: CardProps) {
  const baseClasses = 'rounded-xl transition-all duration-300';
  const hoverClasses = hover ? 'hover:border-slate-600/50 hover:bg-slate-800/60 hover:shadow-xl hover:shadow-slate-900/50' : '';
  const interactiveClasses = interactive ? 'active:scale-95' : '';

  const cardContent = (
    <>
      {/* Header */}
      {(title || icon) && (
        <div className="flex items-start gap-3 mb-4">
          {icon && <div className="text-slate-400 mt-1">{icon}</div>}
          <div>
            {title && <h3 className="text-lg font-semibold text-white">{title}</h3>}
            {subtitle && <p className="text-sm text-slate-400 mt-1">{subtitle}</p>}
          </div>
        </div>
      )}

      {/* Content */}
      {children}

      {/* Footer */}
      {footer && <div className="border-t border-slate-700/50 mt-4 pt-4">{footer}</div>}
    </>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={hover ? { y: -2 } : {}}
      onClick={onClick}
      className={`${baseClasses} ${variantStyles[variant]} ${paddingStyles[padding]} ${hoverClasses} ${interactiveClasses} ${className}`}
    >
      {cardContent}
    </motion.div>
  );
}
